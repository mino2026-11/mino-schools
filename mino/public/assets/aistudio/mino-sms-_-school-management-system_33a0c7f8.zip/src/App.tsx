/**
 * MINO-SMS (School Management System as a Service)
 * Master Application Shell
 * Multi-Tenant Separation, Independent Role Login Pages,
 * Strict Feature & Privilege Allocation, AES-GCM Encrypted Local Vault,
 * 3-Colour Core Palette (#0F172A, #B45309, #065F46).
 */

import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Users,
  BookOpen,
  DollarSign,
  ShieldCheck,
  ShieldAlert,
  History,
  RefreshCw,
  Lock,
  Unlock,
  Wifi,
  WifiOff,
  Menu,
  X,
  ExternalLink,
  Smartphone,
  ChevronDown,
  LayoutDashboard,
  LogOut,
  Award,
  UserCog,
  School
} from 'lucide-react';
import { api } from './services/api';
import { localDb } from './services/db';
import type { SchoolTenant, ClassArm, Subject, Student, UserRole, StaffUser } from './types';
import { StudentDirectory } from './components/StudentDirectory';
import { Gradebook } from './components/Gradebook';
import { FeeLedger } from './components/FeeLedger';
import { ParentPortal } from './components/ParentPortal';
import { StudentPortal } from './components/StudentPortal';
import { StaffManagement } from './components/StaffManagement';
import { AuditTrail } from './components/AuditTrail';
import { VaultModal } from './components/VaultModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { LoginPage } from './components/LoginPage';
import { STRINGS } from './strings/en';

export default function App() {
  // Session & Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');
  const [studentPortalData, setStudentPortalData] = useState<any | null>(null);
  const [parentPortalData, setParentPortalData] = useState<any | null>(null);

  // Multi-Tenant State
  const [availableTenants, setAvailableTenants] = useState<{ id: string; name: string; code: string; currencySymbol: string }[]>([]);
  const [currentSchoolId, setCurrentSchoolId] = useState<string>('sch_oakridge_001');
  const [tenant, setTenant] = useState<SchoolTenant | null>(null);
  const [classes, setClasses] = useState<ClassArm[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [loading, setLoading] = useState(true);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Connectivity & Outbox Sync state
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [outboxCount, setOutboxCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);

  // Vault state
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isVaultUnlocked, setIsVaultUnlocked] = useState(false);

  // Tenant Onboarding Modal
  const [showOnboardModal, setShowOnboardModal] = useState(false);
  const [onboardForm, setOnboardForm] = useState({
    name: '',
    code: '',
    currency: 'NGN',
    currencySymbol: '₦',
    address: '',
    phone: '',
    currentSession: '2025/2026',
    currentTerm: 'First Term'
  });

  // Mobile drawer
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    loadTenantsList();
    loadTenantData(currentSchoolId);
    checkOutboxDepth();

    const handleOnline = () => {
      setIsOnline(true);
      triggerAutoSync();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const interval = setInterval(checkOutboxDepth, 4000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [currentSchoolId]);

  async function loadTenantsList() {
    try {
      const tenants = await api.getTenants();
      setAvailableTenants(tenants);
    } catch (e) {
      console.warn('Failed to load tenants list', e);
    }
  }

  async function loadTenantData(schoolId: string) {
    setLoading(true);
    try {
      api.setSchoolId(schoolId);
      const data = await api.getTenant(schoolId);
      setTenant(data.school);
      setClasses(data.classes);
      setSubjects(data.subjects);
      const studentList = await api.getStudents('all', false);
      setStudents(studentList);
    } catch (err) {
      console.error('Failed to load initial tenant data', err);
    } finally {
      setLoading(false);
    }
  }

  async function checkOutboxDepth() {
    try {
      const count = await localDb.outbox.count();
      setOutboxCount(count);
      setIsVaultUnlocked(api.isVaultUnlocked());
    } catch {
      // safe fallback
    }
  }

  async function triggerAutoSync() {
    if (!navigator.onLine) return;
    setIsSyncing(true);
    try {
      const res = await api.syncOutbox();
      if (res.pushed > 0 || res.skipped > 0) {
        setSyncNotice(`Synced ${res.pushed} offline items. (${res.skipped} deduplicated)`);
        setTimeout(() => setSyncNotice(null), 4000);
      }
      await checkOutboxDepth();
      if (currentSchoolId) await loadTenantData(currentSchoolId);
    } catch (err: any) {
      console.warn('Sync attempt note:', err);
    } finally {
      setIsSyncing(false);
    }
  }

  function handleLockVault() {
    api.setCryptoKey(null);
    setIsVaultUnlocked(false);
    setSyncNotice('Offline vault locked. Keys wiped from active memory.');
    setTimeout(() => setSyncNotice(null), 3000);
  }

  async function handleToggleReportLock(locked: boolean) {
    if (!tenant) return;
    try {
      await api.toggleReportLock(locked, currentUser?.email || 'admin@school.edu');
      setTenant(prev => prev ? { ...prev, isReportsLocked: locked } : null);
      setSyncNotice(locked ? 'Term reports locked. Score mutations disabled.' : 'Term reports unlocked.');
      setTimeout(() => setSyncNotice(null), 3500);
    } catch (err: any) {
      alert(err.message || 'Error updating report lock');
    }
  }

  async function handleOnboardTenantSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = await fetch('/api/tenant/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(onboardForm)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to onboard school');

      setShowOnboardModal(false);
      await loadTenantsList();
      setCurrentSchoolId(data.school.id);
      setSyncNotice(`Onboarded new school tenant: ${data.school.name}`);
      setTimeout(() => setSyncNotice(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Error onboarding tenant');
    }
  }

  function handleLoginSuccess(sessionData: {
    role: UserRole;
    user: any;
    school: SchoolTenant;
    studentPortalData?: any;
    parentPortalData?: any;
  }) {
    setIsLoggedIn(true);
    setCurrentRole(sessionData.role);
    setCurrentUser(sessionData.user);
    setTenant(sessionData.school);
    setStudentPortalData(sessionData.studentPortalData || null);
    setParentPortalData(sessionData.parentPortalData || null);

    // Route default tab by role
    if (sessionData.role === 'student') {
      setActiveTab('student_portal');
    } else if (sessionData.role === 'parent') {
      setActiveTab('parent_portal');
    } else if (sessionData.role === 'teacher') {
      setActiveTab('gradebook');
    } else {
      setActiveTab('dashboard');
    }
  }

  function handleLogout() {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setStudentPortalData(null);
    setParentPortalData(null);
    setActiveTab('dashboard');
  }

  // Filter navigation items strictly based on role privileges
  const getNavItems = () => {
    if (currentRole === 'admin') {
      return [
        { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
        { id: 'students', label: 'Pupils Directory', icon: Users },
        { id: 'staff', label: 'Staff & Subjects', icon: UserCog },
        { id: 'gradebook', label: 'Gradebook', icon: BookOpen },
        { id: 'ledger', label: 'Fees & Ledger', icon: DollarSign },
        { id: 'audit', label: 'Audit Trail', icon: History }
      ];
    }
    if (currentRole === 'teacher') {
      return [
        { id: 'gradebook', label: 'Add Scores & Grades', icon: BookOpen },
        { id: 'students', label: 'Pupils Roster', icon: Users }
      ];
    }
    if (currentRole === 'parent') {
      return [
        { id: 'parent_portal', label: 'Ward Performance & History', icon: GraduationCap }
      ];
    }
    if (currentRole === 'student') {
      return [
        { id: 'student_portal', label: 'Results & Payments', icon: Award }
      ];
    }
    return [];
  };

  const navItems = getNavItems();

  // If NOT logged in, display the Independent Login Pages with Tenant Selector
  if (!isLoggedIn) {
    return (
      <>
        <LoginPage
          availableTenants={availableTenants}
          currentSchoolId={currentSchoolId}
          onSelectTenant={(sid) => {
            setCurrentSchoolId(sid);
            loadTenantData(sid);
          }}
          onOpenOnboardTenant={() => setShowOnboardModal(true)}
          onLoginSuccess={handleLoginSuccess}
        />

        {/* Tenant Onboard Modal */}
        {showOnboardModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="w-full max-w-md rounded-[6px] bg-white p-6 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <School className="w-4 h-4 text-[#B45309]" />
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    Onboard New School Tenant
                  </h3>
                </div>
                <button onClick={() => setShowOnboardModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">✕</button>
              </div>

              <form onSubmit={handleOnboardTenantSubmit} className="mt-4 space-y-3.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    School Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={onboardForm.name}
                    onChange={(e) => setOnboardForm({ ...onboardForm, name: e.target.value })}
                    placeholder="e.g. Greenwood Grammar School"
                    className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      School Code *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={onboardForm.code}
                      onChange={(e) => setOnboardForm({ ...onboardForm, code: e.target.value })}
                      placeholder="GGS"
                      className="w-full px-3 py-2 text-xs uppercase font-mono rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Currency Symbol
                    </label>
                    <input
                      type="text"
                      required
                      value={onboardForm.currencySymbol}
                      onChange={(e) => setOnboardForm({ ...onboardForm, currencySymbol: e.target.value })}
                      placeholder="₦ or $ or €"
                      className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Academic Session
                    </label>
                    <input
                      type="text"
                      value={onboardForm.currentSession}
                      onChange={(e) => setOnboardForm({ ...onboardForm, currentSession: e.target.value })}
                      placeholder="2025/2026"
                      className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Initial Term
                    </label>
                    <select
                      value={onboardForm.currentTerm}
                      onChange={(e) => setOnboardForm({ ...onboardForm, currentTerm: e.target.value })}
                      className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                    >
                      <option value="First Term">First Term</option>
                      <option value="Second Term">Second Term</option>
                      <option value="Third Term">Third Term</option>
                    </select>
                  </div>
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 py-2 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white"
                  >
                    Provision School Tenant
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowOnboardModal(false)}
                    className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-300 text-slate-700 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </>
    );
  }

  // Logged-in App Interface with Role-Restricted Views
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 pb-16 sm:pb-0">
      {/* Primary Authority Header (#0F172A Deep Slate / Obsidian) */}
      <header className="bg-[#0F172A] text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between">
          {/* Brand & Crest */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-[4px] bg-[#1E293B] border border-slate-700 flex items-center justify-center text-[#B45309] font-bold text-sm tracking-wider">
              {tenant?.code?.[0] || 'M'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm tracking-tight text-white font-serif truncate max-w-[160px] sm:max-w-none">
                  {tenant ? tenant.name : 'MINO-SMS'}
                </span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded-[2px] bg-slate-800 text-slate-300 font-semibold">
                  {tenant?.code || 'SMS'}
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-tabular hidden sm:block">
                Session: {tenant?.currentSession || '2025/2026'} · {tenant?.currentTerm || 'Second Term'}
              </div>
            </div>
          </div>

          {/* Right Header Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            <PWAInstallButton />

            {/* Online / Offline Sync Badge */}
            <div className="flex items-center">
              {isOnline ? (
                <button
                  onClick={triggerAutoSync}
                  disabled={isSyncing}
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-[#1E293B] hover:bg-slate-800 border border-slate-700 text-[#065F46] transition-colors"
                  title="Click to trigger outbox sync"
                >
                  <Wifi className="w-3.5 h-3.5 text-[#065F46]" />
                  <span className="hidden md:inline text-slate-200">Online</span>
                  {outboxCount > 0 && (
                    <span className="px-1.5 py-0.2 rounded-[2px] bg-[#B45309] text-white text-[10px] font-mono font-bold">
                      {outboxCount}
                    </span>
                  )}
                  {isSyncing && <RefreshCw className="w-3 h-3 animate-spin text-amber-400" />}
                </button>
              ) : (
                <div
                  className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-[#B45309] text-white"
                  title="Offline mode: changes queued in local AES-GCM vault"
                >
                  <WifiOff className="w-3.5 h-3.5 text-white" />
                  <span className="hidden md:inline">Offline</span>
                  <span className="font-mono text-[10px] font-bold">({outboxCount})</span>
                </div>
              )}
            </div>

            {/* Offline Vault Lock Button */}
            <button
              onClick={() => {
                if (isVaultUnlocked) {
                  handleLockVault();
                } else {
                  setIsVaultOpen(true);
                }
              }}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-[4px] border transition-colors ${
                isVaultUnlocked
                  ? 'bg-emerald-950/60 border-emerald-800 text-[#065F46] hover:bg-emerald-900/80'
                  : 'bg-[#1E293B] border-slate-700 text-slate-300 hover:bg-slate-800'
              }`}
              title={isVaultUnlocked ? 'Vault Unlocked. Click to Lock.' : 'Unlock Local Encrypted Vault'}
            >
              {isVaultUnlocked ? (
                <>
                  <Unlock className="w-3.5 h-3.5 text-[#065F46]" />
                  <span className="hidden sm:inline text-emerald-200">Vault Active</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 text-[#B45309]" />
                  <span className="hidden sm:inline">Unlock Vault</span>
                </>
              )}
            </button>

            {/* User Profile & Role Indicator */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-bold text-white truncate max-w-[120px]">
                  {currentUser?.name || (currentRole === 'student' ? `${currentUser?.firstName} ${currentUser?.lastName}` : 'Staff')}
                </div>
                <div className="text-[10px] text-amber-400 font-mono capitalize">
                  {currentUser?.isHeadTeacher ? 'Head Teacher' : currentRole}
                </div>
              </div>

              {/* Logout / Switch Role Button */}
              <button
                onClick={handleLogout}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-[#1E293B] hover:bg-red-950 text-slate-300 hover:text-red-200 border border-slate-700 transition-colors"
                title="Sign out and return to role login portal"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            </div>

            {/* Mobile Menu Button */}
            {navItems.length > 1 && (
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="sm:hidden p-1.5 text-slate-400 hover:text-white"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Sync / Security Notice Banner */}
      {syncNotice && (
        <div className="bg-[#B45309] text-white text-xs py-1.5 px-4 text-center font-medium shadow-sm transition-all flex items-center justify-center gap-2 font-tabular">
          <span>{syncNotice}</span>
        </div>
      )}

      {/* Main Navigation Subheader (Desktop) */}
      {navItems.length > 1 && (
        <nav className="bg-white border-b border-slate-200 hidden sm:block">
          <div className="max-w-7xl mx-auto px-6 flex items-center space-x-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 py-3 px-3.5 text-xs font-semibold border-b-2 transition-colors ${
                    isActive
                      ? 'border-[#0F172A] text-[#0F172A] bg-slate-50'
                      : 'border-transparent text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#B45309]' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && navItems.length > 1 && (
        <div className="sm:hidden bg-white border-b border-slate-200 p-3 space-y-1 shadow-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-2.5 p-2 text-xs font-semibold rounded-[4px] ${
                  isActive ? 'bg-[#0F172A] text-white' : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-[#B45309]' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Main Content View with Privilege Separation */}
      <main className="max-w-7xl mx-auto w-full p-3 sm:p-6 flex-1">
        {/* ROLE 1: ADMIN & HEAD TEACHER VIEWS */}
        {currentRole === 'admin' && (
          <>
            {/* Overview Dashboard */}
            {activeTab === 'dashboard' && (
              <div className="space-y-6">
                <div className="bg-white border border-slate-200 rounded-[4px] p-4 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                  <div>
                    <h2 className="text-base font-bold text-slate-900 font-serif">
                      {tenant?.name} — Administrator Control Console
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Session: {tenant?.currentSession} · {tenant?.currentTerm} · Currency: {tenant?.currencySymbol}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-600 font-medium">Term Lock:</span>
                    {tenant?.isReportsLocked ? (
                      <span className="px-2 py-0.5 text-xs font-bold text-red-800 bg-red-50 border border-red-200 rounded-[2px] flex items-center gap-1">
                        <Lock className="w-3 h-3" /> Locked
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 text-xs font-bold text-[#065F46] bg-emerald-50 border border-emerald-200 rounded-[2px] flex items-center gap-1">
                        <Unlock className="w-3 h-3" /> Entry Active
                      </span>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-4 bg-white border border-slate-200 rounded-[4px]">
                    <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Enrolled Pupils</div>
                    <div className="text-2xl font-bold text-slate-900 font-tabular mt-1">{students.length}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Onboard / Archive access</div>
                  </div>
                  <div className="p-4 bg-white border border-slate-200 rounded-[4px]">
                    <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Academic Classes</div>
                    <div className="text-2xl font-bold text-slate-900 font-tabular mt-1">{classes.length}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Assigned to staff</div>
                  </div>
                  <div className="p-4 bg-white border border-slate-200 rounded-[4px]">
                    <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Subjects Taught</div>
                    <div className="text-2xl font-bold text-slate-900 font-tabular mt-1">{subjects.length}</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Teacher assignments</div>
                  </div>
                  <div className="p-4 bg-white border border-slate-200 rounded-[4px]">
                    <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Offline Security</div>
                    <div className="text-2xl font-bold text-[#065F46] font-tabular mt-1">AES-256</div>
                    <div className="text-[11px] text-slate-500 mt-0.5">Zero-trust firewall</div>
                  </div>
                </div>

                {/* Direct Action Hub */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    onClick={() => setActiveTab('students')}
                    className="p-4 bg-white border border-slate-200 rounded-[4px] hover:border-[#0F172A] text-left transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                      <span>Onboard & Manage Pupils</span>
                      <Users className="w-4 h-4 text-[#B45309]" />
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Individual enrolment, CSV batch staging, and soft-delete/restore archive.
                    </p>
                  </button>

                  <button
                    onClick={() => setActiveTab('staff')}
                    className="p-4 bg-white border border-slate-200 rounded-[4px] hover:border-[#0F172A] text-left transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                      <span>Staff & Duty Assignments</span>
                      <UserCog className="w-4 h-4 text-[#065F46]" />
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Onboard teachers, assign subjects and class arms, and appoint Head Teacher.
                    </p>
                  </button>

                  <button
                    onClick={() => setActiveTab('ledger')}
                    className="p-4 bg-white border border-slate-200 rounded-[4px] hover:border-[#0F172A] text-left transition-colors"
                  >
                    <div className="flex items-center justify-between text-xs font-bold text-slate-900">
                      <span>Fees & Financial Ledger</span>
                      <DollarSign className="w-4 h-4 text-[#0F172A]" />
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1">
                      Integer fee billing, payment reconciliation, and SHA-256 verified receipts.
                    </p>
                  </button>
                </div>
              </div>
            )}

            {/* Pupils Directory */}
            {activeTab === 'students' && (
              <StudentDirectory
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@oakridge.edu'}
                classes={classes}
              />
            )}

            {/* Staff & Subject Assignments */}
            {activeTab === 'staff' && (
              <StaffManagement
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@oakridge.edu'}
                classes={classes}
                subjects={subjects}
              />
            )}

            {/* Gradebook */}
            {activeTab === 'gradebook' && (
              <Gradebook
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@oakridge.edu'}
                classes={classes}
                subjects={subjects}
                isReportsLocked={tenant?.isReportsLocked || false}
                onToggleReportLock={handleToggleReportLock}
                onSyncTriggered={triggerAutoSync}
              />
            )}

            {/* Fees & Ledger */}
            {activeTab === 'ledger' && (
              <FeeLedger
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@oakridge.edu'}
                students={students}
                currencySymbol={tenant?.currencySymbol || '₦'}
              />
            )}

            {/* Audit Trail */}
            {activeTab === 'audit' && (
              <AuditTrail
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@oakridge.edu'}
                onDataRestored={() => loadTenantData(currentSchoolId)}
              />
            )}
          </>
        )}

        {/* ROLE 2: TEACHER VIEWS (Focused exclusively on adding student scores & grades) */}
        {currentRole === 'teacher' && (
          <>
            {activeTab === 'gradebook' && (
              <div className="space-y-4">
                <div className="bg-white border border-slate-200 rounded-[4px] p-4 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                  <div>
                    <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                      Teacher Gradebook Console
                    </h2>
                    <p className="text-xs text-slate-500">
                      Logged in as: <strong className="text-slate-900">{currentUser?.name}</strong> · Enter scores across CA 1, CA 2, Mid-Term, and Exam.
                    </p>
                  </div>
                  {currentUser?.assignedClasses?.length > 0 && (
                    <div className="text-xs text-slate-600">
                      Authorized Classes: <strong className="text-[#065F46]">{currentUser.assignedClasses.join(', ')}</strong>
                    </div>
                  )}
                </div>

                <Gradebook
                  currentRole="teacher"
                  userEmail={currentUser?.email || 'teacher@oakridge.edu'}
                  classes={classes}
                  subjects={subjects}
                  isReportsLocked={tenant?.isReportsLocked || false}
                  onToggleReportLock={handleToggleReportLock}
                  onSyncTriggered={triggerAutoSync}
                  assignedClasses={currentUser?.assignedClasses}
                  assignedSubjects={currentUser?.assignedSubjects}
                />
              </div>
            )}

            {activeTab === 'students' && (
              <div className="space-y-4">
                <div className="bg-white border border-slate-200 rounded-[4px] p-3 text-xs text-slate-600">
                  Viewing pupil roster for your teaching classes. Note: Only School Administrators can enrol or remove pupils.
                </div>
                <StudentDirectory
                  currentRole="teacher"
                  userEmail={currentUser?.email || 'teacher@oakridge.edu'}
                  classes={currentUser?.assignedClasses?.length > 0 ? classes.filter(c => currentUser.assignedClasses.includes(c.name)) : classes}
                />
              </div>
            )}
          </>
        )}

        {/* ROLE 3: PARENT VIEW (Academic performance & multi-term history) */}
        {currentRole === 'parent' && (
          <ParentPortal
            initialReportData={parentPortalData}
            onLogout={handleLogout}
          />
        )}

        {/* ROLE 4: STUDENT VIEW (Results, pending payments, performance history) */}
        {currentRole === 'student' && studentPortalData && (
          <StudentPortal
            studentData={studentPortalData}
            onLogout={handleLogout}
          />
        )}
      </main>

      {/* Mobile Sticky Thumb Action Bar */}
      {navItems.length > 1 && (
        <div className="sm:hidden fixed bottom-0 left-0 right-0 h-14 bg-[#0F172A] border-t border-slate-800 flex items-center justify-around px-2 z-40">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center justify-center w-14 h-12 rounded-[4px] ${
                  isActive ? 'text-[#B45309]' : 'text-slate-400'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="text-[10px] font-semibold mt-0.5">{item.label.split(' ')[0]}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* Master 6-digit PIN Encryption Vault Modal */}
      <VaultModal
        isOpen={isVaultOpen}
        onClose={() => setIsVaultOpen(false)}
        onUnlockSuccess={() => {
          setIsVaultUnlocked(true);
          setSyncNotice('Local AES-GCM-256 Vault unlocked.');
          setTimeout(() => setSyncNotice(null), 3000);
        }}
      />
    </div>
  );
}
