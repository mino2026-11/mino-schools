/**
 * MINO-SMS Authoritative API Client & Offline Orchestrator
 * Ensures all mutations pass through server validation, with seamless outbox fallback.
 */

import { localDb, getDeviceId } from './db';
import { encryptData, decryptData } from './crypto';
import type { Student, ScoreEvent, LedgerEntry, OutboxItem, SchoolTenant } from '../types';

export class MinoApiClient {
  private activeCryptoKey: CryptoKey | null = null;
  private currentSchoolId: string = 'sch_oakridge_001';

  setCryptoKey(key: CryptoKey | null) {
    this.activeCryptoKey = key;
  }

  setSchoolId(schoolId: string) {
    this.currentSchoolId = schoolId;
  }

  getSchoolId() {
    return this.currentSchoolId;
  }

  isVaultUnlocked(): boolean {
    return this.activeCryptoKey !== null;
  }

  // --- HEALTH & SECURITY VERIFICATION ---
  async getHealth() {
    const res = await fetch('/api/health');
    return await res.json();
  }

  async verifyDirectAccessBlocked(): Promise<{ blocked: boolean; details: any }> {
    try {
      const res = await fetch('/api/security/verify-direct-access', { method: 'POST' });
      const data = await res.json();
      return { blocked: res.status === 403, details: data };
    } catch (err: any) {
      return { blocked: true, details: { error: err.message } };
    }
  }

  // --- TENANT API ---
  async getTenants(): Promise<{ id: string; name: string; code: string; currencySymbol: string; currentSession: string; currentTerm: string }[]> {
    const res = await fetch('/api/tenants');
    if (!res.ok) throw new Error('Failed to load school tenants');
    const data = await res.json();
    return data.tenants;
  }

  async getTenant(schoolId?: string): Promise<{ school: SchoolTenant; classes: any[]; subjects: any[]; feeStructures: any[] }> {
    const sid = schoolId || this.currentSchoolId;
    const res = await fetch(`/api/tenant?schoolId=${sid}`);
    if (!res.ok) throw new Error('Failed to load school tenant');
    return await res.json();
  }

  async toggleReportLock(isReportsLocked: boolean, actorEmail: string) {
    const res = await fetch('/api/tenant/toggle-lock', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ schoolId: this.currentSchoolId, isReportsLocked, actorEmail })
    });
    return await res.json();
  }

  // --- STAFF & ROLE MANAGEMENT (Admin/Head Teacher) ---
  async getStaff(schoolId?: string) {
    const sid = schoolId || this.currentSchoolId;
    const res = await fetch(`/api/staff?schoolId=${sid}`);
    if (!res.ok) throw new Error('Failed to fetch staff directory');
    const data = await res.json();
    return data.staff;
  }

  async createStaff(staffData: any, actorEmail: string) {
    const res = await fetch('/api/staff', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...staffData, schoolId: this.currentSchoolId, actorEmail })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to onboard staff member');
    }
    return await res.json();
  }

  async updateStaff(staffId: string, updates: any, actorEmail: string) {
    const res = await fetch(`/api/staff/${staffId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...updates, schoolId: this.currentSchoolId, actorEmail })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update staff assignments');
    }
    return await res.json();
  }

  async deleteStaff(staffId: string, actorEmail: string) {
    const res = await fetch(`/api/staff/${staffId}?schoolId=${this.currentSchoolId}&actorEmail=${encodeURIComponent(actorEmail)}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Failed to remove staff member');
    return await res.json();
  }

  // --- INDEPENDENT ROLE LOGINS ---
  async loginStaff(email: string, role: string, schoolId?: string) {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, role, schoolId: schoolId || this.currentSchoolId })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Login failed');
    }
    return await res.json();
  }

  async loginStudent(admissionNo: string, studentPin: string, schoolId?: string) {
    const res = await fetch('/api/student/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ admissionNo, studentPin, schoolId: schoolId || this.currentSchoolId })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Student login failed');
    }
    return await res.json();
  }

  // --- STUDENTS DIRECTORY ---
  async getStudents(classArm?: string, includeDeleted = false): Promise<Student[]> {
    const url = `/api/students?schoolId=${this.currentSchoolId}&includeDeleted=${includeDeleted}${classArm && classArm !== 'all' ? `&classArm=${encodeURIComponent(classArm)}` : ''}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch students');
    const data = await res.json();
    return data.students;
  }

  async createStudent(studentData: Partial<Student>, actorEmail: string): Promise<Student> {
    // If online, post to server. If offline, write to encrypted outbox.
    if (!navigator.onLine) {
      return await this.queueOfflineStudent(studentData, 'create');
    }

    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...studentData, schoolId: this.currentSchoolId, actorEmail })
      });
      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Failed to create student');
      }
      const data = await res.json();
      return data.student;
    } catch (err) {
      if (!navigator.onLine || (err instanceof TypeError && err.message.includes('fetch'))) {
        return await this.queueOfflineStudent(studentData, 'create');
      }
      throw err;
    }
  }

  async updateStudent(studentId: string, updates: Partial<Student>, actorEmail: string): Promise<Student> {
    if (!navigator.onLine) {
      return await this.queueOfflineStudent({ ...updates, id: studentId }, 'update');
    }

    const res = await fetch(`/api/students/${studentId}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...updates, schoolId: this.currentSchoolId, actorEmail })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to update student');
    }
    const data = await res.json();
    return data.student;
  }

  async deleteStudent(studentId: string, actorEmail: string): Promise<void> {
    const res = await fetch(`/api/students/${studentId}?schoolId=${this.currentSchoolId}&actorEmail=${encodeURIComponent(actorEmail)}`, {
      method: 'DELETE'
    });
    if (!res.ok) throw new Error('Failed to delete student');
  }

  async restoreStudent(studentId: string, actorEmail: string): Promise<void> {
    const res = await fetch(`/api/students/${studentId}/restore`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ schoolId: this.currentSchoolId, actorEmail })
    });
    if (!res.ok) throw new Error('Failed to restore student');
  }

  async bulkImportCsv(students: any[], actorEmail: string) {
    const res = await fetch('/api/students/bulk-import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ schoolId: this.currentSchoolId, students, actorEmail })
    });
    return await res.json();
  }

  // --- GRADEBOOK ---
  async getScores(classArm?: string, subjectId?: string, session = '2025/2026', term = 'Second Term'): Promise<ScoreEvent[]> {
    let url = `/api/scores?schoolId=${this.currentSchoolId}&session=${encodeURIComponent(session)}&term=${encodeURIComponent(term)}`;
    if (classArm && classArm !== 'all') url += `&classArm=${encodeURIComponent(classArm)}`;
    if (subjectId && subjectId !== 'all') url += `&subjectId=${encodeURIComponent(subjectId)}`;

    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to fetch score events');
    const data = await res.json();
    return data.scores;
  }

  // Queue a score update into outbox or push immediately
  async recordScore(scoreData: {
    studentId: string;
    subjectId: string;
    session: string;
    term: string;
    ca1: number;
    ca2: number;
    midterm: number;
    exam: number;
    recordedBy: string;
  }) {
    const clientChangeId = 'cc_' + crypto.randomUUID();
    const deviceId = getDeviceId();
    const timestamp = new Date().toISOString();

    // If online, try direct sync push
    if (navigator.onLine) {
      try {
        const res = await fetch('/api/sync/push', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            schoolId: this.currentSchoolId,
            items: [
              {
                clientChangeId,
                entity: 'score',
                action: 'create',
                deviceId,
                payload: scoreData,
                timestamp
              }
            ]
          })
        });
        const data = await res.json();
        if (data.results?.[0]?.status === 'rejected') {
          throw new Error(data.results[0].reason || 'Score update rejected by server.');
        }
        return { clientChangeId, synced: true };
      } catch (err: any) {
        if (err.message && err.message.includes('locked')) throw err;
        // Network failure, fallback to outbox
      }
    }

    // Queue in encrypted local outbox
    await this.queueOutboxItem({
      clientChangeId,
      schoolId: this.currentSchoolId,
      entity: 'score',
      action: 'create',
      deviceId,
      timestamp,
      payload: scoreData
    });

    return { clientChangeId, synced: false, queuedOffline: true };
  }

  // --- LEDGER & FEES ---
  async getLedger(studentId?: string): Promise<{ entries: LedgerEntry[]; studentBalances: Record<string, any> }> {
    let url = `/api/ledger?schoolId=${this.currentSchoolId}`;
    if (studentId) url += `&studentId=${studentId}`;
    const res = await fetch(url);
    if (!res.ok) throw new Error('Failed to load ledger');
    return await res.json();
  }

  async recordPayment(paymentData: {
    studentId: string;
    type: 'DEBIT_FEE' | 'CREDIT_PAYMENT' | 'WAIVER';
    amountMinor: number;
    description: string;
    category?: string;
    paymentChannel?: string;
    referenceNo?: string;
    actorEmail: string;
  }) {
    const clientChangeId = 'cc_' + crypto.randomUUID();
    const deviceId = getDeviceId();
    const timestamp = new Date().toISOString();

    if (navigator.onLine) {
      try {
        const res = await fetch('/api/ledger/record', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...paymentData, schoolId: this.currentSchoolId })
        });
        if (res.ok) {
          const data = await res.json();
          return { ...data.entry, synced: true };
        }
      } catch (err) {
        // Fallback to offline queue
      }
    }

    // Queue in encrypted outbox
    await this.queueOutboxItem({
      clientChangeId,
      schoolId: this.currentSchoolId,
      entity: 'ledger',
      action: 'create',
      deviceId,
      timestamp,
      payload: paymentData
    });

    return {
      clientChangeId,
      studentId: paymentData.studentId,
      type: paymentData.type,
      amountMinor: paymentData.amountMinor,
      description: paymentData.description,
      receiptNo: 'OFFLINE-' + Date.now().toString().slice(-6),
      timestamp,
      synced: false,
      queuedOffline: true
    };
  }

  // --- OUTBOX QUEUEING & ENCRYPTION ---
  private async queueOutboxItem(item: {
    clientChangeId: string;
    schoolId: string;
    entity: 'student' | 'score' | 'ledger';
    action: 'create' | 'update' | 'delete';
    deviceId: string;
    timestamp: string;
    payload: any;
  }) {
    let cipherHex = '';
    let ivHex = '';

    if (this.activeCryptoKey) {
      const encrypted = await encryptData(this.activeCryptoKey, item.payload);
      cipherHex = encrypted.cipherHex;
      ivHex = encrypted.ivHex;
    } else {
      // Unencrypted fallback if vault not yet initialized
      cipherHex = btoa(unescape(encodeURIComponent(JSON.stringify(item.payload))));
      ivHex = 'unencrypted_base64';
    }

    await localDb.outbox.add({
      clientChangeId: item.clientChangeId,
      schoolId: item.schoolId,
      entity: item.entity,
      action: item.action,
      deviceId: item.deviceId,
      payloadCipher: cipherHex,
      iv: ivHex,
      timestamp: item.timestamp,
      syncAttempts: 0,
      status: 'pending'
    });
  }

  private async queueOfflineStudent(studentData: Partial<Student>, action: 'create' | 'update'): Promise<Student> {
    const clientChangeId = 'cc_' + crypto.randomUUID();
    const deviceId = getDeviceId();
    const timestamp = new Date().toISOString();
    const tempStudent: Student = {
      id: studentData.id || 'std_off_' + Math.random().toString(36).substring(2, 8),
      schoolId: this.currentSchoolId,
      admissionNo: studentData.admissionNo || 'TEMP-' + Math.floor(1000 + Math.random() * 9000),
      firstName: studentData.firstName || '',
      lastName: studentData.lastName || '',
      gender: studentData.gender || 'other',
      classArm: studentData.classArm || 'JSS 1 Alpha',
      guardianName: studentData.guardianName || '',
      guardianPhone: studentData.guardianPhone || '',
      guardianEmail: studentData.guardianEmail || '',
      accessToken: 'tok_off_' + Date.now(),
      accessPin: '000000',
      studentPin: studentData.studentPin || '1234',
      status: 'active',
      isDeleted: false,
      createdAt: timestamp,
      updatedAt: timestamp
    };

    await this.queueOutboxItem({
      clientChangeId,
      schoolId: this.currentSchoolId,
      entity: 'student',
      action,
      deviceId,
      timestamp,
      payload: tempStudent
    });

    return tempStudent;
  }

  // --- SYNC PUSH WORKER ---
  async syncOutbox(): Promise<{ pushed: number; failed: number; skipped: number }> {
    if (!navigator.onLine) {
      return { pushed: 0, failed: 0, skipped: 0 };
    }

    const pending = await localDb.outbox.where('status').equals('pending').toArray();
    if (pending.length === 0) {
      return { pushed: 0, failed: 0, skipped: 0 };
    }

    // Decrypt items before sending to server
    const batch: any[] = [];
    const validOutboxItems: OutboxItem[] = [];

    for (const item of pending) {
      try {
        let payload: any;
        if (item.iv === 'unencrypted_base64') {
          payload = JSON.parse(decodeURIComponent(escape(atob(item.payloadCipher))));
        } else if (this.activeCryptoKey) {
          payload = await decryptData(this.activeCryptoKey, item.payloadCipher, item.iv);
        } else {
          // Cannot decrypt without active PIN key; skip until vault is unlocked
          continue;
        }

        batch.push({
          clientChangeId: item.clientChangeId,
          entity: item.entity,
          action: item.action,
          deviceId: item.deviceId,
          payload,
          timestamp: item.timestamp
        });
        validOutboxItems.push(item);
      } catch (e) {
        console.error('Failed to decrypt outbox item', item.clientChangeId, e);
      }
    }

    if (batch.length === 0) {
      return { pushed: 0, failed: 0, skipped: pending.length };
    }

    try {
      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          schoolId: this.currentSchoolId,
          items: batch
        })
      });

      if (!res.ok) throw new Error('Sync push failed');
      const data = await res.json();

      // Mark successful items as synced or clean them up
      for (const item of validOutboxItems) {
        if (item.id) {
          await localDb.outbox.delete(item.id);
        }
      }

      return {
        pushed: data.processedCount || 0,
        skipped: data.skippedIdempotentCount || 0,
        failed: batch.length - (data.processedCount || 0) - (data.skippedIdempotentCount || 0)
      };
    } catch (err) {
      console.error('Sync push network failure', err);
      return { pushed: 0, failed: batch.length, skipped: 0 };
    }
  }

  // --- PARENT PORTAL LOOKUP ---
  async lookupParentPortal(query: { admissionNo?: string; accessPin?: string; accessToken?: string }) {
    const res = await fetch('/api/parent/lookup', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...query, schoolId: this.currentSchoolId })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to lookup student record');
    }
    return await res.json();
  }

  // --- AUDIT TRAIL ---
  async getAuditLogs() {
    const res = await fetch(`/api/audit?schoolId=${this.currentSchoolId}`);
    if (!res.ok) throw new Error('Failed to fetch audit logs');
    const data = await res.json();
    return data.logs;
  }

  // --- BACKUP & RESTORE ---
  getBackupDownloadUrl() {
    return `/api/backup/export?schoolId=${this.currentSchoolId}`;
  }

  async restoreBackup(snapshot: any, actorEmail: string) {
    const res = await fetch('/api/backup/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ snapshot, actorEmail })
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to restore snapshot');
    }
    return await res.json();
  }

  async softWipeAndReseed(actorEmail: string) {
    const res = await fetch('/api/admin/soft-wipe', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ schoolId: this.currentSchoolId, actorEmail })
    });
    return await res.json();
  }
}

export const api = new MinoApiClient();
