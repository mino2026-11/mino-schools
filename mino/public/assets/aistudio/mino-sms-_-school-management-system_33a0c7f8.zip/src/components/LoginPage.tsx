/**
 * MINO-SMS Independent Multi-Tenant Role Login Engine
 * Independent login pages and authentication doors for each role:
 * 1. Admin & Head Teacher Portal
 * 2. Class Teacher Portal
 * 3. Parent / Guardian Portal
 * 4. Student Portal
 */

import React, { useState, useEffect } from 'react';
import {
  Shield,
  BookOpen,
  Users,
  GraduationCap,
  Award,
  ArrowRight,
  School,
  Lock,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import type { UserRole, SchoolTenant } from '../types';

interface LoginPageProps {
  onLoginSuccess: (sessionData: {
    role: UserRole;
    user: any;
    school: SchoolTenant;
    studentPortalData?: any;
    parentPortalData?: any;
  }) => void;
  availableTenants: { id: string; name: string; code: string; currencySymbol: string }[];
  currentSchoolId: string;
  onSelectTenant: (schoolId: string) => void;
  onOpenOnboardTenant: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  availableTenants,
  currentSchoolId,
  onSelectTenant,
  onOpenOnboardTenant
}) => {
  const [activePortal, setActivePortal] = useState<'admin' | 'teacher' | 'parent' | 'student'>('admin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form states
  // 1. Admin Form
  const [adminEmail, setAdminEmail] = useState('admin@oakridge.edu');
  const [adminPass, setAdminPass] = useState('••••••••');

  // 2. Teacher Form
  const [teacherEmail, setTeacherEmail] = useState('teacher@oakridge.edu');
  const [teacherPass, setTeacherPass] = useState('••••••••');

  // 3. Parent Form
  const [parentAdmNo, setParentAdmNo] = useState('OMA/2024/001');
  const [parentPin, setParentPin] = useState('849201');

  // 4. Student Form
  const [studentAdmNo, setStudentAdmNo] = useState('OMA/2024/001');
  const [studentPin, setStudentPin] = useState('1234');

  async function handleAdminLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.loginStaff(adminEmail, 'admin', currentSchoolId);
      onLoginSuccess({
        role: 'admin',
        user: data.user,
        school: data.school
      });
    } catch (err: any) {
      setError(err.message || 'Admin login failed.');
    } finally {
      setLoading(false);
    }
  }

  async function handleTeacherLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.loginStaff(teacherEmail, 'teacher', currentSchoolId);
      onLoginSuccess({
        role: 'teacher',
        user: data.user,
        school: data.school
      });
    } catch (err: any) {
      setError(err.message || 'Teacher login failed.');
    } finally {
      setLoading(false);
    }
  }

  async function handleParentLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.lookupParentPortal({ admissionNo: parentAdmNo, accessPin: parentPin });
      onLoginSuccess({
        role: 'parent',
        user: { name: data.student.guardianName || 'Guardian', email: 'guardian@example.com' },
        school: data.school,
        parentPortalData: data
      });
    } catch (err: any) {
      setError(err.message || 'Parent record lookup failed.');
    } finally {
      setLoading(false);
    }
  }

  async function handleStudentLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.loginStudent(studentAdmNo, studentPin, currentSchoolId);
      onLoginSuccess({
        role: 'student',
        user: data.student,
        school: data.school,
        studentPortalData: data
      });
    } catch (err: any) {
      setError(err.message || 'Student login failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8">
      {/* Brand Header */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-[4px] bg-[#0F172A] text-[#B45309] font-bold text-xl shadow-md border border-slate-800">
          M
        </div>
        <h1 className="mt-3 text-2xl font-bold font-serif text-slate-900 tracking-tight">
          MINO-SMS
        </h1>
        <p className="text-xs text-slate-600 font-medium">
          Multi-Tenant School Management & Offline Service Engine
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-xl">
        {/* Tenant Selection Card */}
        <div className="mb-4 bg-white p-3.5 rounded-[4px] border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-[#B45309]" />
            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Target School Tenant
              </span>
              <select
                value={currentSchoolId}
                onChange={(e) => onSelectTenant(e.target.value)}
                className="text-xs font-bold text-slate-900 bg-transparent border-none p-0 focus:ring-0 cursor-pointer"
              >
                {availableTenants.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={onOpenOnboardTenant}
            className="text-[11px] font-semibold text-[#0F172A] hover:text-[#B45309] underline"
          >
            + Onboard New School Tenant
          </button>
        </div>

        {/* Independent Portal Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 p-1 bg-slate-200 rounded-[4px] border border-slate-300">
          <button
            onClick={() => { setActivePortal('admin'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'admin'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <Shield className={`w-4 h-4 ${activePortal === 'admin' ? 'text-[#B45309]' : 'text-slate-500'}`} />
            <span>Admin / Head</span>
          </button>

          <button
            onClick={() => { setActivePortal('teacher'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'teacher'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <BookOpen className={`w-4 h-4 ${activePortal === 'teacher' ? 'text-[#065F46]' : 'text-slate-500'}`} />
            <span>Teacher Portal</span>
          </button>

          <button
            onClick={() => { setActivePortal('parent'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'parent'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <Users className={`w-4 h-4 ${activePortal === 'parent' ? 'text-[#B45309]' : 'text-slate-500'}`} />
            <span>Guardian Portal</span>
          </button>

          <button
            onClick={() => { setActivePortal('student'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'student'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <GraduationCap className={`w-4 h-4 ${activePortal === 'student' ? 'text-[#065F46]' : 'text-slate-500'}`} />
            <span>Student Portal</span>
          </button>
        </div>

        {/* Dedicated Portal Body */}
        <div className="mt-3 bg-white p-6 rounded-[4px] border border-slate-200 shadow-md space-y-4">
          {/* Privilege Separation Header */}
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-[3px] text-xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
              Allocated Role Privileges
            </span>
            {activePortal === 'admin' && (
              <p className="text-slate-700 font-medium mt-0.5 leading-relaxed">
                <strong className="text-slate-900">Administrator / Head Teacher:</strong> Full authority to onboard & remove students and staff, assign teaching subjects and class arms, appoint Head Teacher, manage fee ledger, and control term report locks.
              </p>
            )}
            {activePortal === 'teacher' && (
              <p className="text-slate-700 font-medium mt-0.5 leading-relaxed">
                <strong className="text-slate-900">Class Teacher:</strong> Add student scores across Continuous Assessment (CA1, CA2), Mid-term, and Examination. Automatically compute performance grades, calculate averages, and submit evaluation remarks.
              </p>
            )}
            {activePortal === 'parent' && (
              <p className="text-slate-700 font-medium mt-0.5 leading-relaxed">
                <strong className="text-slate-900">Parent / Guardian:</strong> Direct read-only access to view your ward's verified terminal performance, examination results, historical trends across terms, attendance, and fee clearance status.
              </p>
            )}
            {activePortal === 'student' && (
              <p className="text-slate-700 font-medium mt-0.5 leading-relaxed">
                <strong className="text-slate-900">Enrolled Student:</strong> Direct access to view terminal examination results, review pending payments and school fees, analyze subject performance, and inspect payment receipts.
              </p>
            )}
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-[3px] text-xs text-red-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. ADMIN LOGIN FORM */}
          {activePortal === 'admin' && (
            <form onSubmit={handleAdminLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Administrator Email
                </label>
                <input
                  type="email"
                  required
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  placeholder="admin@school.edu"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Security Passcode
                </label>
                <input
                  type="password"
                  required
                  value={adminPass}
                  onChange={(e) => setAdminPass(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In as Administrator'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[11px] text-slate-500">
                <span>Preset Demo Account:</span>
                <button
                  type="button"
                  onClick={() => { setAdminEmail('admin@oakridge.edu'); }}
                  className="font-mono text-[#B45309] hover:underline"
                >
                  admin@oakridge.edu (Dr. Balogun)
                </button>
              </div>
            </form>
          )}

          {/* 2. TEACHER LOGIN FORM */}
          {activePortal === 'teacher' && (
            <form onSubmit={handleTeacherLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Teacher Staff Email
                </label>
                <input
                  type="email"
                  required
                  value={teacherEmail}
                  onChange={(e) => setTeacherEmail(e.target.value)}
                  placeholder="teacher@school.edu"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Teacher Access PIN
                </label>
                <input
                  type="password"
                  required
                  value={teacherPass}
                  onChange={(e) => setTeacherPass(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Entering Teacher Portal...' : 'Sign In to Gradebook'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 border-t border-slate-100 flex flex-col gap-1 text-[11px] text-slate-500">
                <span className="font-semibold">Quick Teacher Accounts:</span>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => { setTeacherEmail('teacher@oakridge.edu'); }}
                    className="font-mono text-[#065F46] hover:underline"
                  >
                    Mr. Ogunlesi (Math/Science)
                  </button>
                  <button
                    type="button"
                    onClick={() => { setTeacherEmail('english.teacher@oakridge.edu'); }}
                    className="font-mono text-[#065F46] hover:underline"
                  >
                    Mrs. Achebe (English/Social)
                  </button>
                </div>
              </div>
            </form>
          )}

          {/* 3. PARENT LOGIN FORM */}
          {activePortal === 'parent' && (
            <form onSubmit={handleParentLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Pupil Admission Number
                </label>
                <input
                  type="text"
                  required
                  value={parentAdmNo}
                  onChange={(e) => setParentAdmNo(e.target.value)}
                  placeholder="e.g. OMA/2024/001"
                  className="w-full px-3 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  6-digit Guardian Access PIN
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  required
                  value={parentPin}
                  onChange={(e) => setParentPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••••"
                  className="w-full px-3 py-2 text-xs font-mono tracking-widest text-center rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#B45309] hover:bg-[#92400E] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Retrieving Child Record...' : 'View Student Performance & History'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[11px] text-slate-500">
                <span>Demo Guardian:</span>
                <button
                  type="button"
                  onClick={() => { setParentAdmNo('OMA/2024/001'); setParentPin('849201'); }}
                  className="font-mono text-[#B45309] hover:underline"
                >
                  OMA/2024/001 (Chidinma Okafor)
                </button>
              </div>
            </form>
          )}

          {/* 4. STUDENT LOGIN FORM */}
          {activePortal === 'student' && (
            <form onSubmit={handleStudentLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Student Admission Number
                </label>
                <input
                  type="text"
                  required
                  value={studentAdmNo}
                  onChange={(e) => setStudentAdmNo(e.target.value)}
                  placeholder="e.g. OMA/2024/001"
                  className="w-full px-3 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Student Passcode / PIN
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  required
                  value={studentPin}
                  onChange={(e) => setStudentPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••"
                  className="w-full px-3 py-2 text-xs font-mono tracking-widest text-center rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#065F46] hover:bg-[#064E3B] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Checking Results...' : 'View Results & Pending Payments'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 border-t border-slate-100 flex flex-col gap-1 text-[11px] text-slate-500">
                <span className="font-semibold">Quick Student Accounts:</span>
                <div className="flex gap-3">
                  <button
                    type="button"
                    onClick={() => { setStudentAdmNo('OMA/2024/001'); setStudentPin('1234'); }}
                    className="font-mono text-[#065F46] hover:underline"
                  >
                    Chidinma (OMA/2024/001)
                  </button>
                  <button
                    type="button"
                    onClick={() => { setStudentAdmNo('OMA/2024/002'); setStudentPin('2345'); }}
                    className="font-mono text-[#065F46] hover:underline"
                  >
                    Babatunde (OMA/2024/002)
                  </button>
                </div>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
