/**
 * MINO-SMS Parent Access Portal & Low-Data Mobile Engine
 * Token-based lookup (Admission No + 6-digit PIN).
 * Low-data mode (<15KB payload) for spotty 2G/3G connections.
 * Student Performance & History Inspection across terms.
 * Print-friendly report cards & instant WhatsApp/SMS communication generator.
 */

import React, { useState } from 'react';
import { Search, Printer, MessageSquare, Copy, Check, Smartphone, ShieldCheck, AlertCircle, Award, History, LogOut } from 'lucide-react';
import { api } from '../services/api';

interface ParentPortalProps {
  initialReportData?: any;
  onLogout?: () => void;
}

export const ParentPortal: React.FC<ParentPortalProps> = ({ initialReportData, onLogout }) => {
  const [admissionNo, setAdmissionNo] = useState('OMA/2024/001');
  const [accessPin, setAccessPin] = useState('849201');
  const [loading, setLoading] = useState(false);
  const [reportData, setReportData] = useState<any | null>(initialReportData || null);
  const [error, setError] = useState<string | null>(null);
  const [lowDataMode, setLowDataMode] = useState(false);
  const [copiedTemplate, setCopiedTemplate] = useState<string | null>(null);
  const [activeSection, setActiveSection] = useState<'current' | 'history'>('current');

  async function handleLookup(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const data = await api.lookupParentPortal({ admissionNo, accessPin });
      setReportData(data);
    } catch (err: any) {
      setError(err.message || 'Failed to retrieve student record');
      setReportData(null);
    } finally {
      setLoading(false);
    }
  }

  function copyToClipboard(text: string, templateKey: string) {
    navigator.clipboard.writeText(text);
    setCopiedTemplate(templateKey);
    setTimeout(() => setCopiedTemplate(null), 2500);
  }

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Lookup & Authentication Header */}
      <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm no-print">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-4 border-b border-slate-100">
          <div>
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
              Guardian Academic & Financial Portal
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Secure, token-authenticated terminal performance & fee clearance verification
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Low Data Mode Toggle */}
            <button
              onClick={() => setLowDataMode(!lowDataMode)}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-[4px] border transition-colors ${
                lowDataMode
                  ? 'bg-amber-100 border-[#B45309] text-[#B45309]'
                  : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Low-Data Mode {lowDataMode ? '(Active)' : '(Off)'}</span>
            </button>

            {onLogout && (
              <button
                onClick={onLogout}
                className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Exit Portal</span>
              </button>
            )}
          </div>
        </div>

        {!initialReportData && (
          <form onSubmit={handleLookup} className="mt-4 flex flex-col sm:flex-row gap-3">
            <div className="flex-1">
              <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                Pupil Admission Number
              </label>
              <input
                type="text"
                required
                value={admissionNo}
                onChange={(e) => setAdmissionNo(e.target.value)}
                placeholder="e.g. OMA/2024/001"
                className="w-full px-3 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
              />
            </div>

            <div className="w-full sm:w-44">
              <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                6-digit Access PIN
              </label>
              <input
                type="password"
                inputMode="numeric"
                maxLength={6}
                required
                value={accessPin}
                onChange={(e) => setAccessPin(e.target.value.replace(/\D/g, ''))}
                placeholder="••••••"
                className="w-full px-3 py-2 text-xs font-mono tracking-widest text-center rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
              />
            </div>

            <div className="sm:self-end">
              <button
                type="submit"
                disabled={loading}
                className="w-full sm:w-auto px-5 py-2 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white disabled:opacity-50 transition-colors"
              >
                {loading ? 'Retrieving...' : 'Retrieve Report Card'}
              </button>
            </div>
          </form>
        )}

        {error && (
          <div className="mt-4 p-3 rounded-[4px] bg-red-50 border border-red-200 text-xs text-red-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Verified Student Report Card Output */}
      {reportData && (
        <div className={`space-y-4 ${lowDataMode ? 'font-mono text-xs' : ''}`}>
          {/* Section Toggle: Current Term vs History */}
          <div className="flex p-0.5 bg-slate-200 rounded-[4px] border border-slate-300 no-print">
            <button
              onClick={() => setActiveSection('current')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-[3px] transition-colors ${
                activeSection === 'current' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Current Performance ({reportData.school.currentTerm})
            </button>
            <button
              onClick={() => setActiveSection('history')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-[3px] flex items-center justify-center gap-1.5 transition-colors ${
                activeSection === 'history' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <History className="w-3.5 h-3.5 text-[#B45309]" />
              <span>Academic Performance History</span>
            </button>
          </div>

          {activeSection === 'current' ? (
            /* Printable Report Header */
            <div className="bg-white border border-slate-200 rounded-[4px] p-6 shadow-sm print:border-none print:shadow-none">
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-4 border-b border-slate-200 gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-[4px] bg-[#0F172A] text-white flex items-center justify-center font-bold text-lg font-serif">
                    {reportData.school.code}
                  </div>
                  <div>
                    <h1 className="text-base font-bold text-slate-900 uppercase font-serif tracking-wide">
                      {reportData.school.name}
                    </h1>
                    <p className="text-xs text-slate-500">
                      Official Student Terminal Assessment & Clearance Transcript
                    </p>
                    <p className="text-[11px] text-slate-400 font-tabular">
                      Session: {reportData.school.currentSession} · {reportData.school.currentTerm}
                    </p>
                  </div>
                </div>

                {/* Fee Clearance Banner */}
                <div className="sm:text-right">
                  {reportData.financialStatus.isCleared ? (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-[4px] bg-emerald-50 text-[#065F46] border border-emerald-200 font-semibold text-xs">
                      <ShieldCheck className="w-4 h-4 text-[#065F46]" />
                      <span>Fees Fully Cleared</span>
                    </div>
                  ) : (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-[4px] bg-amber-50 text-[#B45309] border border-amber-200 font-semibold text-xs">
                      <AlertCircle className="w-4 h-4 text-[#B45309]" />
                      <span>
                        Arrears: {reportData.school.currencySymbol}{(reportData.financialStatus.arrearsMinor / 100).toLocaleString()}
                      </span>
                    </div>
                  )}
                  <div className="mt-2 no-print">
                    <button
                      onClick={() => window.print()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-[4px] bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      <span>Print Report Card</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Student Metadata Strip */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-3 border-b border-slate-100 text-xs">
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Student Name</span>
                  <span className="font-bold text-slate-900">{reportData.student.firstName} {reportData.student.lastName}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Admission Number</span>
                  <span className="font-mono font-medium text-slate-800">{reportData.student.admissionNo}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Class Arm</span>
                  <span className="font-medium text-slate-800">{reportData.student.classArm}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] uppercase font-semibold">Term Attendance</span>
                  <span className="font-bold text-[#065F46] font-tabular">{reportData.academicReport.attendanceRate}</span>
                </div>
              </div>

              {/* Subject Matrix */}
              <div className="mt-4 overflow-x-auto">
                <table className="mino-table">
                  <thead>
                    <tr>
                      <th>Subject</th>
                      <th className="text-center w-20">CA 1 (15)</th>
                      <th className="text-center w-20">CA 2 (15)</th>
                      <th className="text-center w-20">Mid (20)</th>
                      <th className="text-center w-20">Exam (50)</th>
                      <th className="text-center w-24 font-bold">Total (100)</th>
                      <th className="text-center w-20">Grade</th>
                      <th>Teacher Remark</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.academicReport.scores.map((sc: any, idx: number) => (
                      <tr key={idx}>
                        <td className="font-semibold text-slate-900">{sc.subjectName}</td>
                        <td className="text-center font-tabular text-slate-700">{sc.ca1}</td>
                        <td className="text-center font-tabular text-slate-700">{sc.ca2}</td>
                        <td className="text-center font-tabular text-slate-700">{sc.midterm}</td>
                        <td className="text-center font-tabular text-slate-700">{sc.exam}</td>
                        <td className="text-center font-tabular font-bold text-slate-900">{sc.total}</td>
                        <td className="text-center font-bold">
                          <span className={`inline-block px-2 py-0.5 rounded-[2px] text-xs ${
                            sc.grade === 'A' ? 'bg-emerald-100 text-[#065F46]' :
                            sc.grade === 'B' ? 'bg-emerald-50 text-emerald-800' :
                            sc.grade === 'C' ? 'bg-amber-100 text-[#B45309]' : 'bg-red-50 text-red-800'
                          }`}>
                            {sc.grade}
                          </span>
                        </td>
                        <td className="text-xs text-slate-600">{sc.remark}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Performance Summary Footnote */}
              <div className="mt-4 pt-3 border-t border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#B45309]" />
                  <span className="font-semibold text-slate-900">
                    Cumulative Term Average: <span className="text-[#065F46] font-bold font-tabular text-sm">{reportData.academicReport.averageScore}%</span>
                  </span>
                  <span className="text-slate-400">({reportData.academicReport.totalSubjects} subjects evaluated)</span>
                </div>
                <div className="text-slate-400 font-mono text-[10px]">
                  Authentication Hash: Verified Cloud Signature
                </div>
              </div>
            </div>
          ) : (
            /* Historical Performance View Across Terms */
            <div className="bg-white border border-slate-200 rounded-[4px] p-6 shadow-sm space-y-4">
              <div className="flex justify-between items-center pb-3 border-b border-slate-200">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    Historical Academic Performance & Multi-Term History
                  </h3>
                  <p className="text-xs text-slate-500">Track grade trends and subject mastery across completed terms</p>
                </div>
                <div className="font-tabular text-xs font-semibold text-slate-700">
                  Pupil: {reportData.student.firstName} {reportData.student.lastName}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {reportData.history?.map((hist: any, i: number) => (
                  <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
                    <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{hist.term}</h4>
                        <span className="text-[11px] text-slate-500">{hist.session}</span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] uppercase font-semibold text-slate-500 block">Term Average</span>
                        <span className="text-base font-bold text-[#065F46] font-tabular">{hist.averageScore}%</span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-xs font-tabular">
                      {hist.scores?.map((s: any, idx: number) => (
                        <div key={idx} className="flex justify-between py-1 border-b border-slate-100">
                          <span className="text-slate-700 font-sans">{s.subjectName}</span>
                          <span className="font-bold text-slate-900">
                            {s.total}/100 <span className="text-xs font-semibold text-[#065F46]">({s.grade})</span>
                          </span>
                        </div>
                      ))}
                    </div>

                    <div className="pt-2 text-[11px] text-slate-500 flex justify-between border-t border-slate-100">
                      <span>Attendance: <strong>{hist.attendance}</strong></span>
                      <span className="text-[#065F46] font-semibold">Transcript Archival Record</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Parent Communication Templates (SMS / WhatsApp Dispatch) */}
          <div className="bg-white border border-slate-200 rounded-[4px] p-4 shadow-sm no-print space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <MessageSquare className="w-4 h-4 text-[#B45309]" />
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
                Guardian Communication Templates (SMS / WhatsApp Dispatch)
              </h3>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {/* Terminal Report Release Template */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-[4px] space-y-2">
                <div className="font-semibold text-slate-800">Results Release Notification</div>
                <p className="text-slate-600 font-mono text-[11px] leading-relaxed">
                  Dear Parent of {reportData.student.firstName}, the {reportData.school.currentTerm} {reportData.school.currentSession} report card has been released. Avg: {reportData.academicReport.averageScore}%. Access PIN: {accessPin}. — {reportData.school.name}
                </p>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => copyToClipboard(
                      `Dear Parent of ${reportData.student.firstName}, the ${reportData.school.currentTerm} ${reportData.school.currentSession} report card has been released. Avg: ${reportData.academicReport.averageScore}%. Access PIN: ${accessPin}. — ${reportData.school.name}`,
                      'report'
                    )}
                    className="px-2 py-1 text-[11px] font-semibold rounded-[2px] bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1"
                  >
                    {copiedTemplate === 'report' ? <Check className="w-3 h-3 text-[#065F46]" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedTemplate === 'report' ? 'Copied' : 'Copy Text'}</span>
                  </button>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(`Dear Parent of ${reportData.student.firstName}, the ${reportData.school.currentTerm} ${reportData.school.currentSession} report card has been released. Avg: ${reportData.academicReport.averageScore}%. Access PIN: ${accessPin}. — ${reportData.school.name}`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2 py-1 text-[11px] font-semibold rounded-[2px] bg-[#065F46] text-white hover:bg-[#064E3B] inline-flex items-center gap-1"
                  >
                    Send WhatsApp
                  </a>
                </div>
              </div>

              {/* Fee Reminder Template */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-[4px] space-y-2">
                <div className="font-semibold text-slate-800">Fee Settlement Notice</div>
                <p className="text-slate-600 font-mono text-[11px] leading-relaxed">
                  Dear Guardian, this is a gentle reminder that {reportData.student.firstName} ({reportData.student.admissionNo}) has an outstanding balance of {reportData.school.currencySymbol}{(reportData.financialStatus.arrearsMinor / 100).toLocaleString()}. Kindly remit payment. — {reportData.school.name} Bursary
                </p>
                <div className="flex gap-2 pt-1">
                  <button
                    onClick={() => copyToClipboard(
                      `Dear Guardian, this is a gentle reminder that ${reportData.student.firstName} (${reportData.student.admissionNo}) has an outstanding balance of ${reportData.school.currencySymbol}${(reportData.financialStatus.arrearsMinor / 100).toLocaleString()}. Kindly remit payment. — ${reportData.school.name} Bursary`,
                      'fee'
                    )}
                    className="px-2 py-1 text-[11px] font-semibold rounded-[2px] bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 inline-flex items-center gap-1"
                  >
                    {copiedTemplate === 'fee' ? <Check className="w-3 h-3 text-[#065F46]" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedTemplate === 'fee' ? 'Copied' : 'Copy Text'}</span>
                  </button>
                  <a
                    href={`https://wa.me/?text=${encodeURIComponent(`Dear Guardian, this is a gentle reminder that ${reportData.student.firstName} (${reportData.student.admissionNo}) has an outstanding balance of ${reportData.school.currencySymbol}${(reportData.financialStatus.arrearsMinor / 100).toLocaleString()}. Kindly remit payment. — ${reportData.school.name} Bursary`)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-2 py-1 text-[11px] font-semibold rounded-[2px] bg-[#065F46] text-white hover:bg-[#064E3B] inline-flex items-center gap-1"
                  >
                    Send WhatsApp
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
