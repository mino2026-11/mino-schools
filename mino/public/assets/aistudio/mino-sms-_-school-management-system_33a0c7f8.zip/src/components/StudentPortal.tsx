/**
 * MINO-SMS Student Portal
 * Direct pupil view: terminal results, pending payments, performance history & receipts.
 */

import React, { useState } from 'react';
import { Award, BookOpen, DollarSign, CheckCircle2, AlertCircle, History, Printer, ShieldCheck, ChevronRight } from 'lucide-react';

interface StudentPortalProps {
  studentData: any; // Returned from /api/student/login
  onLogout: () => void;
}

export const StudentPortal: React.FC<StudentPortalProps> = ({ studentData, onLogout }) => {
  const [activeTab, setActiveTab] = useState<'results' | 'fees' | 'history'>('results');

  const { student, school, currentReport, history, financialSummary } = studentData;

  function formatMoney(amountMinor: number): string {
    const major = amountMinor / 100;
    return `${school.currencySymbol}${major.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      {/* Student Identity Card */}
      <div className="bg-[#0F172A] text-white p-5 rounded-[4px] shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-mono uppercase bg-slate-800 text-amber-400 px-2 py-0.5 rounded-[2px] font-bold">
              Student Portal
            </span>
            <span className="text-xs text-slate-400">{school.name}</span>
          </div>
          <h1 className="text-lg font-bold font-serif text-white mt-1">
            {student.firstName} {student.lastName}
          </h1>
          <div className="text-xs text-slate-300 flex flex-wrap items-center gap-3 mt-1 font-tabular">
            <span>Admission No: <strong className="font-mono text-white">{student.admissionNo}</strong></span>
            <span>·</span>
            <span>Class: <strong className="text-white">{student.classArm}</strong></span>
            <span>·</span>
            <span>Session: <strong className="text-white">{school.currentSession} ({school.currentTerm})</strong></span>
          </div>
        </div>

        <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 text-xs font-semibold rounded-[4px] bg-[#1E293B] hover:bg-slate-800 text-slate-200 border border-slate-700 flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Transcript</span>
          </button>
          <button
            onClick={onLogout}
            className="px-3 py-1.5 text-xs font-semibold rounded-[4px] bg-red-950 text-red-200 hover:bg-red-900 border border-red-800"
          >
            Sign Out
          </button>
        </div>
      </div>

      {/* Navigation Segmented Control */}
      <div className="flex p-0.5 bg-slate-200 rounded-[4px] border border-slate-300 no-print">
        <button
          onClick={() => setActiveTab('results')}
          className={`flex-1 py-2 text-xs font-semibold rounded-[3px] flex items-center justify-center gap-2 transition-colors ${
            activeTab === 'results' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Award className="w-3.5 h-3.5 text-[#B45309]" />
          <span>Terminal Results</span>
        </button>
        <button
          onClick={() => setActiveTab('fees')}
          className={`flex-1 py-2 text-xs font-semibold rounded-[3px] flex items-center justify-center gap-2 transition-colors ${
            activeTab === 'fees' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <DollarSign className="w-3.5 h-3.5 text-[#065F46]" />
          <span>Pending Payments & Ledger</span>
          {financialSummary.arrearsMinor > 0 && (
            <span className="px-1.5 py-0.2 rounded-[2px] bg-[#B45309] text-white text-[10px] font-mono font-bold">
              Due
            </span>
          )}
        </button>
        <button
          onClick={() => setActiveTab('history')}
          className={`flex-1 py-2 text-xs font-semibold rounded-[3px] flex items-center justify-center gap-2 transition-colors ${
            activeTab === 'history' ? 'bg-white text-slate-900 shadow-sm' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <History className="w-3.5 h-3.5 text-[#0F172A]" />
          <span>Performance History</span>
        </button>
      </div>

      {/* TAB 1: TERMINAL RESULTS VIEW */}
      {activeTab === 'results' && (
        <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-slate-100 gap-2">
            <div>
              <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                Terminal Examination Results & Scores
              </h2>
              <p className="text-xs text-slate-500">{school.currentSession} · {school.currentTerm}</p>
            </div>
            <div className="flex items-center gap-2 font-tabular">
              <span className="text-xs text-slate-500 font-semibold">Cumulative Average:</span>
              <span className="text-lg font-bold text-[#065F46]">{currentReport.averageScore}%</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="mino-table">
              <thead>
                <tr>
                  <th>Subject</th>
                  <th className="text-center w-20">CA 1 (15)</th>
                  <th className="text-center w-20">CA 2 (15)</th>
                  <th className="text-center w-20">Mid (20)</th>
                  <th className="text-center w-20">Exam (50)</th>
                  <th className="text-center w-24 font-bold">Total (100)</th>
                  <th className="text-center w-20">Grade</th>
                  <th>Teacher Remark</th>
                </tr>
              </thead>
              <tbody>
                {currentReport.scores.map((sc: any, idx: number) => (
                  <tr key={idx}>
                    <td className="font-semibold text-slate-900">{sc.subjectName}</td>
                    <td className="text-center font-tabular text-slate-700">{sc.ca1}</td>
                    <td className="text-center font-tabular text-slate-700">{sc.ca2}</td>
                    <td className="text-center font-tabular text-slate-700">{sc.midterm}</td>
                    <td className="text-center font-tabular text-slate-700">{sc.exam}</td>
                    <td className="text-center font-tabular font-bold text-slate-900">{sc.total}</td>
                    <td className="text-center font-bold">
                      <span className={`inline-block px-2 py-0.5 rounded-[2px] text-xs ${
                        sc.grade === 'A' ? 'bg-emerald-100 text-[#065F46]' :
                        sc.grade === 'B' ? 'bg-emerald-50 text-emerald-800' :
                        sc.grade === 'C' ? 'bg-amber-100 text-[#B45309]' : 'bg-red-50 text-red-800'
                      }`}>
                        {sc.grade}
                      </span>
                    </td>
                    <td className="text-xs text-slate-600">{sc.remark}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="pt-2 flex justify-between items-center text-xs text-slate-500 border-t border-slate-100">
            <span>Verified Terminal Evaluation Record</span>
            <span className="font-tabular">Term Attendance Rate: {currentReport.attendanceRate}</span>
          </div>
        </div>
      )}

      {/* TAB 2: PENDING PAYMENTS & FEES VIEW */}
      {activeTab === 'fees' && (
        <div className="space-y-4">
          {/* Clearance Status Summary */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-white border border-slate-200 rounded-[4px]">
              <span className="text-[11px] font-semibold text-slate-500 uppercase">Total Billed Fees</span>
              <div className="text-lg font-bold text-slate-900 font-tabular mt-1">
                {formatMoney(financialSummary.totalBilledMinor)}
              </div>
            </div>
            <div className="p-3 bg-white border border-slate-200 rounded-[4px]">
              <span className="text-[11px] font-semibold text-[#065F46] uppercase">Total Amount Paid</span>
              <div className="text-lg font-bold text-[#065F46] font-tabular mt-1">
                {formatMoney(financialSummary.totalPaidMinor)}
              </div>
            </div>
            <div className="p-3 bg-white border border-slate-200 rounded-[4px]">
              <span className="text-[11px] font-semibold text-[#B45309] uppercase">Pending Arrears</span>
              <div className="text-lg font-bold text-[#B45309] font-tabular mt-1">
                {formatMoney(financialSummary.arrearsMinor)}
              </div>
            </div>
          </div>

          {/* Pending Bills Breakdown */}
          <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide pb-2 border-b border-slate-100">
              Fee Assessment Schedule
            </h3>
            <div className="space-y-2">
              {financialSummary.pendingBills.map((bill: any, i: number) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-[4px] bg-slate-50 border border-slate-200 text-xs">
                  <div>
                    <div className="font-semibold text-slate-900">{bill.description}</div>
                    <div className="text-[11px] text-slate-500">Category: {bill.category} · Billed: {new Date(bill.dateBilled).toLocaleDateString()}</div>
                  </div>
                  <div className="font-bold text-slate-900 font-tabular">
                    {formatMoney(bill.amountMinor)}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Payment Receipts History */}
          <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide pb-2 border-b border-slate-100">
              Verified Payment Receipts
            </h3>
            {financialSummary.recentReceipts.length === 0 ? (
              <p className="text-xs text-slate-400 py-3">No payments recorded yet.</p>
            ) : (
              <div className="space-y-2">
                {financialSummary.recentReceipts.map((rec: any, idx: number) => (
                  <div key={idx} className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 rounded-[4px] bg-emerald-50/50 border border-emerald-200 text-xs gap-2">
                    <div>
                      <div className="font-semibold text-slate-900 flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-[#065F46]" />
                        <span>Receipt: {rec.receiptNo}</span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-0.5">
                        Channel: {rec.channel} · Date: {new Date(rec.date).toLocaleDateString()}
                      </div>
                      {rec.verificationHash && (
                        <div className="text-[10px] font-mono text-slate-400 mt-0.5">
                          Hash: {rec.verificationHash.slice(0, 16)}...
                        </div>
                      )}
                    </div>
                    <div className="font-bold text-[#065F46] font-tabular text-sm">
                      {formatMoney(rec.amountMinor)}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 3: PERFORMANCE HISTORY VIEW */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm space-y-4">
            <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide pb-2 border-b border-slate-100">
              Academic Performance Trajectory Across Terms
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {history.map((termRecord: any, i: number) => (
                <div key={i} className="p-4 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-200">
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{termRecord.term}</h4>
                      <span className="text-[11px] text-slate-500">{termRecord.session}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] uppercase font-semibold text-slate-500 block">Average</span>
                      <span className="text-base font-bold text-[#065F46] font-tabular">{termRecord.averageScore}%</span>
                    </div>
                  </div>

                  <div className="space-y-1 text-xs">
                    {termRecord.scores.map((s: any, idx: number) => (
                      <div key={idx} className="flex justify-between py-1 border-b border-slate-100 font-tabular">
                        <span className="text-slate-700">{s.subjectName}</span>
                        <span className="font-semibold text-slate-900">{s.total}/100 ({s.grade})</span>
                      </div>
                    ))}
                  </div>

                  <div className="pt-1 text-[11px] text-slate-500 flex justify-between">
                    <span>Attendance: {termRecord.attendance}</span>
                    <span className="text-[#065F46] font-semibold">Evaluated</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
