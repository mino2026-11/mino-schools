/**
 * MINO-SMS Ergonomic Gradebook & Offline Sync Engine
 * Desktop Keyboard Grid Navigation (Arrow keys, Tab, Enter, Escape)
 * Mobile Thumb-Zone Number Entry Pad (>=48px touch targets)
 * Idempotent Outbox Queue & Immutable Report Release Lock
 */

import React, { useState, useEffect, useRef } from 'react';
import { Lock, Unlock, RefreshCw, Check, CloudOff, AlertTriangle, ArrowRight, Smartphone, Keyboard } from 'lucide-react';
import { api } from '../services/api';
import type { Student, ScoreEvent, Subject, ClassArm } from '../types';

interface GradebookProps {
  currentRole: string;
  userEmail: string;
  classes: ClassArm[];
  subjects: Subject[];
  isReportsLocked: boolean;
  onToggleReportLock: (locked: boolean) => void;
  onSyncTriggered?: () => void;
  assignedClasses?: string[];
  assignedSubjects?: string[];
}

export const Gradebook: React.FC<GradebookProps> = ({
  currentRole,
  userEmail,
  classes,
  subjects,
  isReportsLocked,
  onToggleReportLock,
  onSyncTriggered,
  assignedClasses,
  assignedSubjects
}) => {
  // If teacher has assigned classes/subjects, restrict dropdown to them
  const filteredClasses = assignedClasses && assignedClasses.length > 0 && currentRole === 'teacher'
    ? classes.filter(c => assignedClasses.includes(c.name))
    : classes;

  const filteredSubjects = assignedSubjects && assignedSubjects.length > 0 && currentRole === 'teacher'
    ? subjects.filter(s => assignedSubjects.includes(s.id))
    : subjects;

  const [selectedClass, setSelectedClass] = useState(filteredClasses[0]?.name || classes[0]?.name || 'JSS 1 Alpha');
  const [selectedSubject, setSelectedSubject] = useState(filteredSubjects[0]?.id || subjects[0]?.id || 'sub_math');
  const [students, setStudents] = useState<Student[]>([]);
  const [scores, setScores] = useState<Record<string, ScoreEvent>>({});
  const [loading, setLoading] = useState(true);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Active cell for Desktop Keyboard Navigation: rowIndex (0..N-1), colKey ('ca1' | 'ca2' | 'midterm' | 'exam')
  const [activeCell, setActiveCell] = useState<{ rowIndex: number; colKey: 'ca1' | 'ca2' | 'midterm' | 'exam' } | null>(null);
  const [mobileEntryStudentId, setMobileEntryStudentId] = useState<string | null>(null);
  const [mobileActiveField, setMobileActiveField] = useState<'ca1' | 'ca2' | 'midterm' | 'exam'>('ca1');

  // Local working copy of scores being edited
  const [editValues, setEditValues] = useState<Record<string, { ca1: number; ca2: number; midterm: number; exam: number }>>({});
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({});

  const COLS: Array<'ca1' | 'ca2' | 'midterm' | 'exam'> = ['ca1', 'ca2', 'midterm', 'exam'];
  const MAX_LIMITS = { ca1: 15, ca2: 15, midterm: 20, exam: 50 };

  useEffect(() => {
    loadGradebookData();
  }, [selectedClass, selectedSubject]);

  async function loadGradebookData() {
    setLoading(true);
    try {
      const studentList = await api.getStudents(selectedClass, false);
      const scoreList = await api.getScores(selectedClass, selectedSubject);

      setStudents(studentList);
      const scoreMap: Record<string, ScoreEvent> = {};
      const initialEditMap: Record<string, { ca1: number; ca2: number; midterm: number; exam: number }> = {};

      scoreList.forEach(sc => {
        scoreMap[sc.studentId] = sc;
      });

      studentList.forEach(st => {
        const existing = scoreMap[st.id];
        initialEditMap[st.id] = {
          ca1: existing ? existing.ca1 : 0,
          ca2: existing ? existing.ca2 : 0,
          midterm: existing ? existing.midterm : 0,
          exam: existing ? existing.exam : 0
        };
      });

      setScores(scoreMap);
      setEditValues(initialEditMap);
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to load gradebook records' });
    } finally {
      setLoading(false);
    }
  }

  function handleValueChange(studentId: string, field: 'ca1' | 'ca2' | 'midterm' | 'exam', val: number) {
    if (isReportsLocked) return;
    const max = MAX_LIMITS[field];
    const clamped = Math.min(max, Math.max(0, isNaN(val) ? 0 : val));

    setEditValues(prev => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: clamped
      }
    }));
  }

  async function commitScoreRow(studentId: string) {
    if (isReportsLocked) return;
    const row = editValues[studentId];
    if (!row) return;

    try {
      const res = await api.recordScore({
        studentId,
        subjectId: selectedSubject,
        session: '2025/2026',
        term: 'Second Term',
        ca1: row.ca1,
        ca2: row.ca2,
        midterm: row.midterm,
        exam: row.exam,
        recordedBy: userEmail
      });

      // Update in memory
      const total = row.ca1 + row.ca2 + row.midterm + row.exam;
      let grade: any = 'F';
      let remark = 'Fail';
      if (total >= 80) { grade = 'A'; remark = 'Distinction'; }
      else if (total >= 70) { grade = 'B'; remark = 'Very Good'; }
      else if (total >= 60) { grade = 'C'; remark = 'Good Credit'; }
      else if (total >= 50) { grade = 'D'; remark = 'Pass'; }
      else if (total >= 40) { grade = 'E'; remark = 'Marginal Pass'; }

      setScores(prev => ({
        ...prev,
        [studentId]: {
          id: 'sc_' + studentId,
          clientChangeId: res.clientChangeId,
          schoolId: api.getSchoolId(),
          studentId,
          subjectId: selectedSubject,
          session: '2025/2026',
          term: 'Second Term',
          ca1: row.ca1,
          ca2: row.ca2,
          midterm: row.midterm,
          exam: row.exam,
          total,
          grade,
          remark,
          recordedBy: userEmail,
          deviceId: 'local',
          timestamp: new Date().toISOString(),
          synced: res.synced
        }
      }));

      if (res.queuedOffline) {
        setFeedback({ type: 'success', message: 'Score saved to encrypted local outbox (ready for sync).' });
      }
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Error recording score' });
    }
  }

  // Keyboard Grid Navigation
  function handleKeyDown(
    e: React.KeyboardEvent<HTMLInputElement>,
    rowIndex: number,
    colKey: 'ca1' | 'ca2' | 'midterm' | 'exam',
    studentId: string
  ) {
    const colIndex = COLS.indexOf(colKey);

    if (e.key === 'ArrowRight' || e.key === 'Tab') {
      if (e.key === 'Tab' && e.shiftKey) return; // allow normal shift-tab
      e.preventDefault();
      commitScoreRow(studentId);
      if (colIndex < COLS.length - 1) {
        focusCell(rowIndex, COLS[colIndex + 1]);
      } else if (rowIndex < students.length - 1) {
        focusCell(rowIndex + 1, COLS[0]);
      }
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      commitScoreRow(studentId);
      if (colIndex > 0) {
        focusCell(rowIndex, COLS[colIndex - 1]);
      } else if (rowIndex > 0) {
        focusCell(rowIndex - 1, COLS[COLS.length - 1]);
      }
    } else if (e.key === 'ArrowDown' || e.key === 'Enter') {
      e.preventDefault();
      commitScoreRow(studentId);
      if (rowIndex < students.length - 1) {
        focusCell(rowIndex + 1, colKey);
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      commitScoreRow(studentId);
      if (rowIndex > 0) {
        focusCell(rowIndex - 1, colKey);
      }
    } else if (e.key === 'Escape') {
      e.currentTarget.blur();
      setActiveCell(null);
    }
  }

  function focusCell(rowIndex: number, colKey: 'ca1' | 'ca2' | 'midterm' | 'exam') {
    const key = `${rowIndex}_${colKey}`;
    const input = inputRefs.current[key];
    if (input) {
      input.focus();
      input.select();
      setActiveCell({ rowIndex, colKey });
    }
  }

  // Mobile Thumb Pad Key Click Handler
  function handleMobileKeypadDigit(digit: number) {
    if (!mobileEntryStudentId || isReportsLocked) return;
    const currentVal = editValues[mobileEntryStudentId]?.[mobileActiveField] || 0;
    const newVal = currentVal === 0 ? digit : Number(`${currentVal}${digit}`);
    handleValueChange(mobileEntryStudentId, mobileActiveField, newVal);
  }

  function handleMobileKeypadClear() {
    if (!mobileEntryStudentId || isReportsLocked) return;
    handleValueChange(mobileEntryStudentId, mobileActiveField, 0);
  }

  function handleMobileKeypadNext() {
    if (!mobileEntryStudentId) return;
    commitScoreRow(mobileEntryStudentId);
    const currIdx = COLS.indexOf(mobileActiveField);
    if (currIdx < COLS.length - 1) {
      setMobileActiveField(COLS[currIdx + 1]);
    } else {
      // Advance to next student
      const stIdx = students.findIndex(s => s.id === mobileEntryStudentId);
      if (stIdx < students.length - 1) {
        setMobileEntryStudentId(students[stIdx + 1].id);
        setMobileActiveField(COLS[0]);
      }
    }
  }

  return (
    <div className="space-y-4">
      {/* Gradebook Header & Controls */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 bg-white border border-slate-200 rounded-[4px]">
        <div className="flex flex-wrap items-center gap-2">
          {/* Class Selector */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Class:</span>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-[4px] border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-[#0F172A]"
            >
              {classes.map(c => (
                <option key={c.id} value={c.name}>{c.name}</option>
              ))}
            </select>
          </div>

          {/* Subject Selector */}
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Subject:</span>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="px-2.5 py-1.5 text-xs font-semibold rounded-[4px] border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-[#0F172A]"
            >
              {subjects.map(s => (
                <option key={s.id} value={s.id}>{s.name} ({s.code})</option>
              ))}
            </select>
          </div>

          <span className="hidden md:inline-block text-xs text-slate-400">|</span>
          <span className="text-xs text-slate-600 font-medium font-tabular">Session: 2025/2026 · Second Term</span>
        </div>

        {/* Lock Indicator & Actions */}
        <div className="flex items-center gap-2">
          {isReportsLocked ? (
            <div className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-red-50 text-red-800 border border-red-200">
              <Lock className="w-3.5 h-3.5 text-red-700" />
              <span>Reports Locked</span>
            </div>
          ) : (
            <div className="flex items-center gap-1 px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-emerald-50 text-[#065F46] border border-emerald-200">
              <Unlock className="w-3.5 h-3.5 text-[#065F46]" />
              <span>Score Entry Active</span>
            </div>
          )}

          {currentRole === 'admin' && (
            <button
              onClick={() => onToggleReportLock(!isReportsLocked)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-[4px] border transition-colors ${
                isReportsLocked
                  ? 'bg-white hover:bg-slate-50 text-slate-800 border-slate-300'
                  : 'bg-[#0F172A] hover:bg-[#1E293B] text-white border-transparent'
              }`}
            >
              {isReportsLocked ? 'Unlock Term Reports' : 'Lock & Finalize Term'}
            </button>
          )}
        </div>
      </div>

      {feedback && (
        <div className={`p-3 rounded-[4px] text-xs flex items-center justify-between border ${
          feedback.type === 'success' ? 'bg-emerald-50 border-emerald-200 text-[#065F46]' : 'bg-red-50 border-red-200 text-red-800'
        }`}>
          <span>{feedback.message}</span>
          <button onClick={() => setFeedback(null)} className="font-bold ml-2">✕</button>
        </div>
      )}

      {/* Keyboard Shortcuts Hint Bar for Desktop */}
      <div className="hidden sm:flex items-center justify-between px-3 py-1.5 bg-slate-100 rounded-[4px] text-[11px] text-slate-600 border border-slate-200 font-tabular">
        <div className="flex items-center gap-4">
          <span className="font-semibold text-slate-800 flex items-center gap-1">
            <Keyboard className="w-3.5 h-3.5 text-[#B45309]" /> Grid Navigation:
          </span>
          <span><kbd className="px-1.5 py-0.5 rounded-[2px] bg-white border border-slate-300 text-slate-800 font-mono text-[10px]">Tab</kbd> / <kbd className="px-1.5 py-0.5 rounded-[2px] bg-white border border-slate-300 text-slate-800 font-mono text-[10px]">Enter</kbd> to save & advance</span>
          <span><kbd className="px-1.5 py-0.5 rounded-[2px] bg-white border border-slate-300 text-slate-800 font-mono text-[10px]">Arrow Keys</kbd> to move</span>
          <span><kbd className="px-1.5 py-0.5 rounded-[2px] bg-white border border-slate-300 text-slate-800 font-mono text-[10px]">Esc</kbd> to cancel</span>
        </div>
        <span className="text-slate-500">Weight: CA1 (15) + CA2 (15) + Mid (20) + Exam (50) = 100</span>
      </div>

      {/* Gradebook Grid Table */}
      <div className="bg-white border border-slate-200 rounded-[4px] overflow-hidden shadow-sm">
        <div className="overflow-x-auto">
          <table className="mino-table">
            <thead>
              <tr>
                <th className="w-28">ID</th>
                <th className="min-w-[180px]">Pupil Name</th>
                <th className="w-24 text-center">CA 1 (15)</th>
                <th className="w-24 text-center">CA 2 (15)</th>
                <th className="w-24 text-center">Mid (20)</th>
                <th className="w-24 text-center">Exam (50)</th>
                <th className="w-24 text-center font-bold">Total (100)</th>
                <th className="w-20 text-center">Grade</th>
                <th className="w-28">Remark</th>
                <th className="w-20 text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={10} className="text-center py-8 text-slate-400">Loading student scores...</td>
                </tr>
              ) : students.length === 0 ? (
                <tr>
                  <td colSpan={10} className="text-center py-8 text-slate-400">No pupils found for class {selectedClass}.</td>
                </tr>
              ) : (
                students.map((student, rowIndex) => {
                  const currentEdit = editValues[student.id] || { ca1: 0, ca2: 0, midterm: 0, exam: 0 };
                  const total = currentEdit.ca1 + currentEdit.ca2 + currentEdit.midterm + currentEdit.exam;
                  const isCurrentMobile = mobileEntryStudentId === student.id;

                  let grade = 'F';
                  let remark = 'Fail';
                  if (total >= 80) { grade = 'A'; remark = 'Distinction'; }
                  else if (total >= 70) { grade = 'B'; remark = 'Very Good'; }
                  else if (total >= 60) { grade = 'C'; remark = 'Good Credit'; }
                  else if (total >= 50) { grade = 'D'; remark = 'Pass'; }
                  else if (total >= 40) { grade = 'E'; remark = 'Marginal Pass'; }

                  const syncedScore = scores[student.id];

                  return (
                    <tr
                      key={student.id}
                      className={isCurrentMobile ? 'bg-amber-50' : ''}
                      onClick={() => setMobileEntryStudentId(student.id)}
                    >
                      <td className="font-mono text-xs text-slate-600">{student.admissionNo}</td>
                      <td className="font-semibold text-slate-900">
                        {student.firstName} {student.lastName}
                      </td>

                      {/* CA 1 */}
                      <td className="p-1 text-center">
                        <input
                          ref={(el) => { inputRefs.current[`${rowIndex}_ca1`] = el; }}
                          type="number"
                          disabled={isReportsLocked}
                          min={0}
                          max={15}
                          value={currentEdit.ca1}
                          onChange={(e) => handleValueChange(student.id, 'ca1', parseInt(e.target.value) || 0)}
                          onKeyDown={(e) => handleKeyDown(e, rowIndex, 'ca1', student.id)}
                          onBlur={() => commitScoreRow(student.id)}
                          onFocus={() => {
                            setActiveCell({ rowIndex, colKey: 'ca1' });
                            setMobileEntryStudentId(student.id);
                            setMobileActiveField('ca1');
                          }}
                          className={`w-16 px-1.5 py-1 text-center text-xs font-semibold rounded-[3px] border font-tabular ${
                            activeCell?.rowIndex === rowIndex && activeCell?.colKey === 'ca1'
                              ? 'border-[#B45309] bg-amber-50 ring-1 ring-[#B45309]'
                              : 'border-slate-300 bg-white hover:border-slate-400'
                          } disabled:bg-slate-100 disabled:text-slate-400`}
                        />
                      </td>

                      {/* CA 2 */}
                      <td className="p-1 text-center">
                        <input
                          ref={(el) => { inputRefs.current[`${rowIndex}_ca2`] = el; }}
                          type="number"
                          disabled={isReportsLocked}
                          min={0}
                          max={15}
                          value={currentEdit.ca2}
                          onChange={(e) => handleValueChange(student.id, 'ca2', parseInt(e.target.value) || 0)}
                          onKeyDown={(e) => handleKeyDown(e, rowIndex, 'ca2', student.id)}
                          onBlur={() => commitScoreRow(student.id)}
                          onFocus={() => {
                            setActiveCell({ rowIndex, colKey: 'ca2' });
                            setMobileEntryStudentId(student.id);
                            setMobileActiveField('ca2');
                          }}
                          className={`w-16 px-1.5 py-1 text-center text-xs font-semibold rounded-[3px] border font-tabular ${
                            activeCell?.rowIndex === rowIndex && activeCell?.colKey === 'ca2'
                              ? 'border-[#B45309] bg-amber-50 ring-1 ring-[#B45309]'
                              : 'border-slate-300 bg-white hover:border-slate-400'
                          } disabled:bg-slate-100 disabled:text-slate-400`}
                        />
                      </td>

                      {/* Midterm */}
                      <td className="p-1 text-center">
                        <input
                          ref={(el) => { inputRefs.current[`${rowIndex}_midterm`] = el; }}
                          type="number"
                          disabled={isReportsLocked}
                          min={0}
                          max={20}
                          value={currentEdit.midterm}
                          onChange={(e) => handleValueChange(student.id, 'midterm', parseInt(e.target.value) || 0)}
                          onKeyDown={(e) => handleKeyDown(e, rowIndex, 'midterm', student.id)}
                          onBlur={() => commitScoreRow(student.id)}
                          onFocus={() => {
                            setActiveCell({ rowIndex, colKey: 'midterm' });
                            setMobileEntryStudentId(student.id);
                            setMobileActiveField('midterm');
                          }}
                          className={`w-16 px-1.5 py-1 text-center text-xs font-semibold rounded-[3px] border font-tabular ${
                            activeCell?.rowIndex === rowIndex && activeCell?.colKey === 'midterm'
                              ? 'border-[#B45309] bg-amber-50 ring-1 ring-[#B45309]'
                              : 'border-slate-300 bg-white hover:border-slate-400'
                          } disabled:bg-slate-100 disabled:text-slate-400`}
                        />
                      </td>

                      {/* Exam */}
                      <td className="p-1 text-center">
                        <input
                          ref={(el) => { inputRefs.current[`${rowIndex}_exam`] = el; }}
                          type="number"
                          disabled={isReportsLocked}
                          min={0}
                          max={50}
                          value={currentEdit.exam}
                          onChange={(e) => handleValueChange(student.id, 'exam', parseInt(e.target.value) || 0)}
                          onKeyDown={(e) => handleKeyDown(e, rowIndex, 'exam', student.id)}
                          onBlur={() => commitScoreRow(student.id)}
                          onFocus={() => {
                            setActiveCell({ rowIndex, colKey: 'exam' });
                            setMobileEntryStudentId(student.id);
                            setMobileActiveField('exam');
                          }}
                          className={`w-16 px-1.5 py-1 text-center text-xs font-semibold rounded-[3px] border font-tabular ${
                            activeCell?.rowIndex === rowIndex && activeCell?.colKey === 'exam'
                              ? 'border-[#B45309] bg-amber-50 ring-1 ring-[#B45309]'
                              : 'border-slate-300 bg-white hover:border-slate-400'
                          } disabled:bg-slate-100 disabled:text-slate-400`}
                        />
                      </td>

                      {/* Computed Total */}
                      <td className="text-center font-bold text-slate-900 font-tabular text-sm">
                        {total}
                      </td>

                      {/* Grade Badge */}
                      <td className="text-center font-bold">
                        <span className={`inline-block px-2 py-0.5 rounded-[2px] text-xs ${
                          grade === 'A' ? 'bg-emerald-100 text-[#065F46]' :
                          grade === 'B' ? 'bg-emerald-50 text-emerald-800' :
                          grade === 'C' ? 'bg-amber-100 text-[#B45309]' :
                          grade === 'D' ? 'bg-amber-50 text-amber-800' :
                          'bg-red-50 text-red-800'
                        }`}>
                          {grade}
                        </span>
                      </td>

                      <td className="text-xs text-slate-600">{remark}</td>

                      <td className="text-center">
                        {syncedScore ? (
                          <span className="text-[10px] font-semibold text-[#065F46] flex items-center justify-center gap-0.5">
                            <Check className="w-3 h-3 text-[#065F46]" /> Synced
                          </span>
                        ) : (
                          <span className="text-[10px] font-semibold text-slate-400">Unsaved</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile Ergonomic Thumb Keypad (Shown on Small Screens / Selected Row) */}
      {mobileEntryStudentId && (
        <div className="block sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t-2 border-slate-900 p-3 shadow-2xl">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-100">
            <div className="text-xs font-bold text-slate-900 truncate">
              {students.find(s => s.id === mobileEntryStudentId)?.firstName} {students.find(s => s.id === mobileEntryStudentId)?.lastName}
            </div>
            <div className="flex gap-1">
              {COLS.map(c => (
                <button
                  key={c}
                  onClick={() => setMobileActiveField(c)}
                  className={`px-2 py-1 text-[11px] font-semibold rounded-[3px] uppercase ${
                    mobileActiveField === c ? 'bg-[#0F172A] text-white' : 'bg-slate-100 text-slate-700'
                  }`}
                >
                  {c} ({MAX_LIMITS[c]})
                </button>
              ))}
            </div>
          </div>

          {/* 48px tactile thumb buttons */}
          <div className="grid grid-cols-4 gap-1.5">
            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map(digit => (
              <button
                key={digit}
                type="button"
                onClick={() => handleMobileKeypadDigit(digit)}
                className="h-12 flex items-center justify-center rounded-[4px] bg-slate-100 hover:bg-slate-200 text-slate-900 font-bold text-base border border-slate-300 active:bg-slate-300"
              >
                {digit}
              </button>
            ))}
            <button
              type="button"
              onClick={handleMobileKeypadClear}
              className="h-12 flex items-center justify-center rounded-[4px] bg-red-50 hover:bg-red-100 text-red-700 font-bold text-xs border border-red-200"
            >
              Clear
            </button>
            <button
              type="button"
              onClick={handleMobileKeypadNext}
              className="h-12 flex items-center justify-center rounded-[4px] bg-[#B45309] hover:bg-[#92400E] text-white font-bold text-xs"
            >
              Next <ArrowRight className="w-3.5 h-3.5 ml-1 inline" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
