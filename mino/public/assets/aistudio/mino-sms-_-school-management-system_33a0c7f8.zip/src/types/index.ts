/**
 * MINO-SMS Core Type Definitions
 * Strict types for multi-tenancy, independent portals, gradebook, and financial ledger.
 */

export type UserRole = 'admin' | 'head_teacher' | 'teacher' | 'bursar' | 'parent' | 'student';

export interface StaffUser {
  id: string;
  schoolId: string;
  name: string;
  email: string;
  role: UserRole;
  isHeadTeacher?: boolean;
  assignedClasses?: string[];
  assignedSubjects?: string[];
  phone?: string;
  createdAt?: string;
}

export interface SchoolTenant {
  id: string;
  name: string;
  code: string;
  currency: string;
  currencySymbol: string;
  address: string;
  phone: string;
  currentSession: string; // e.g. "2025/2026"
  currentTerm: 'First Term' | 'Second Term' | 'Third Term';
  isReportsLocked: boolean;
  createdAt: string;
}

export interface ClassArm {
  id: string;
  schoolId: string;
  name: string; // e.g. "JSS 1 Alpha", "Grade 7A"
  level: string; // e.g. "Junior Secondary", "Primary", "Senior Secondary"
  classTeacherId?: string;
  studentCount?: number;
}

export interface Subject {
  id: string;
  schoolId: string;
  name: string; // e.g. "Mathematics", "English Language", "Basic Science"
  code: string;
}

export interface Student {
  id: string;
  schoolId: string;
  admissionNo: string;
  firstName: string;
  lastName: string;
  gender: 'male' | 'female' | 'other';
  classArm: string; // classArm id or name
  guardianName: string;
  guardianPhone: string;
  guardianEmail: string;
  accessToken: string; // 128-bit or secure token for parent portal lookup
  accessPin: string; // 6-digit access PIN for guardian portal
  studentPin: string; // Passcode for direct student login
  status: 'active' | 'suspended' | 'graduated' | 'withdrawn';
  isDeleted: boolean;
  deletedAt?: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ScoreEvent {
  id: string;
  clientChangeId: string; // UUID for idempotency
  schoolId: string;
  studentId: string;
  subjectId: string;
  session: string;
  term: string;
  ca1: number; // 0 - 15
  ca2: number; // 0 - 15
  midterm: number; // 0 - 20
  exam: number; // 0 - 50
  total: number; // 0 - 100
  grade: 'A' | 'B' | 'C' | 'D' | 'E' | 'F';
  remark: string;
  recordedBy: string;
  deviceId: string;
  timestamp: string;
  synced: boolean;
}

export type PaymentChannel = 'CASH' | 'BANK_TRANSFER' | 'POS' | 'ONLINE';

export interface LedgerEntry {
  id: string;
  clientChangeId: string; // UUID for idempotency
  schoolId: string;
  studentId: string;
  type: 'DEBIT_FEE' | 'CREDIT_PAYMENT' | 'WAIVER';
  amountMinor: number; // Stored in integer kobo/cents. E.g., 5000000 = 50,000.00
  description: string;
  category?: string; // "Tuition", "Uniform", "Books", "PTA", "Development"
  receiptNo?: string;
  paymentChannel?: PaymentChannel;
  referenceNo?: string;
  verificationHash?: string; // SHA-256 HMAC for tamper-evident offline receipts
  recordedBy: string;
  timestamp: string;
  synced: boolean;
}

export interface FeeStructure {
  id: string;
  schoolId: string;
  classArm: string;
  name: string;
  amountMinor: number;
  term: string;
  session: string;
}

export interface OutboxItem {
  id?: number;
  clientChangeId: string;
  schoolId: string;
  entity: 'student' | 'score' | 'ledger';
  action: 'create' | 'update' | 'delete';
  deviceId: string;
  payloadCipher: string; // AES-GCM encrypted payload
  iv: string;
  timestamp: string;
  syncAttempts: number;
  status: 'pending' | 'in_flight' | 'synced' | 'failed';
  lastError?: string;
}

export interface AuditLog {
  id: string;
  schoolId: string;
  actorId: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  entity: string;
  entityId: string;
  details: string;
  ipAddress?: string;
  timestamp: string;
}

export interface VaultMeta {
  isConfigured: boolean;
  saltHex: string;
  canaryCipherHex: string;
  canaryIvHex: string;
  lastUnlockedAt?: string;
}

export interface HistoricalTermReport {
  session: string;
  term: string;
  averageScore: number;
  attendance: string;
  scores: {
    subjectName: string;
    ca1: number;
    ca2: number;
    midterm: number;
    exam: number;
    total: number;
    grade: string;
    remark: string;
  }[];
  totalBilledMinor: number;
  totalPaidMinor: number;
  arrearsMinor: number;
}
