/**
 * MINO-SMS (School Management System as a Service)
 * Master Application Shell
 * Complete implementation of the Figma Community School Management Admin Dashboard UI.
 * Features:
 * - Collapsible High-Fidelity Sidebar Navigation
 * - Top Bar Contract Header with Global Search, Notifications, Sync Status
 * - Executive Dashboard Overview (KPIs, Attendance Bar Chart, Financials, Calendar, Notice Board)
 * - Students Directory with Dossier Inspector & CSV Export
 * - Teachers & Staff Management with Subject Assignments
 * - Parents Directory with WhatsApp/SMS Dispatch
 * - Classes & Weekly Routine Timetable
 * - Daily Roll Call Attendance Register
 * - Academic Gradebook with Keyboard Navigation & Term Lock
 * - Financial Ledger & Fee Collection with SHA-256 Verified Receipts
 * - Notice Board & Official Broadcast Circulars
 * - Master 6-digit PIN AES-GCM-256 Encryption Vault
 * - Immutable Audit Trail & Cold JSON Backup/Restore
 */

import React, { useState, useEffect } from 'react';
import {
  GraduationCap,
  Users,
  BookOpen,
  DollarSign,
  ShieldCheck,
  History,
  RefreshCw,
  Lock,
  Unlock,
  Wifi,
  WifiOff,
  Menu,
  X,
  School,
  PlusCircle,
  FileSpreadsheet
} from 'lucide-react';
import { api } from './services/api';
import { localDb } from './services/db';
import type {
  SchoolTenant,
  ClassArm,
  Subject,
  Student,
  UserRole,
  StaffUser,
  DashboardSummary,
  Notice
} from './types';

// Core Dashboard Components
import { Sidebar } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { DashboardOverview } from './components/DashboardOverview';
import { StudentDirectory } from './components/StudentDirectory';
import { StaffManagement } from './components/StaffManagement';
import { ParentsDirectory } from './components/ParentsDirectory';
import { ClassesTimetable } from './components/ClassesTimetable';
import { AttendanceTracker } from './components/AttendanceTracker';
import { Gradebook } from './components/Gradebook';
import { FeeLedger } from './components/FeeLedger';
import { NoticeBoard } from './components/NoticeBoard';
import { ParentPortal } from './components/ParentPortal';
import { StudentPortal } from './components/StudentPortal';
import { AuditTrail } from './components/AuditTrail';
import { VaultModal } from './components/VaultModal';
import { StudentProfileModal } from './components/StudentProfileModal';
import { LoginPage } from './components/LoginPage';
import { LandingPage } from './components/LandingPage';
import { OwnerLoginModal } from './components/OwnerLoginModal';
import { SuperAdminDashboard } from './components/SuperAdminDashboard';

export default function App() {
  // Master View Navigation: 'landing' | 'school_login' | 'owner_dashboard' | 'school_app'
  const [appMode, setAppMode] = useState<'landing' | 'school_login' | 'owner_dashboard' | 'school_app'>('landing');
  const [showOwnerLoginModal, setShowOwnerLoginModal] = useState(false);
  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  // Session & Authentication State
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [currentRole, setCurrentRole] = useState<UserRole>('admin');
  const [studentPortalData, setStudentPortalData] = useState<any | null>(null);
  const [parentPortalData, setParentPortalData] = useState<any | null>(null);

  // Multi-Tenant State
  const [availableTenants, setAvailableTenants] = useState<{ id: string; name: string; code: string; currencySymbol: string }[]>([]);
  const [currentSchoolId, setCurrentSchoolId] = useState<string>('sch_oakridge_001');
  const [tenant, setTenant] = useState<SchoolTenant | null>(null);
  const [classes, setClasses] = useState<ClassArm[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [students, setStudents] = useState<Student[]>([]);
  const [staff, setStaff] = useState<StaffUser[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  const [dashboardSummary, setDashboardSummary] = useState<DashboardSummary | null>(null);
  const [loading, setLoading] = useState(true);

  // Active navigation tab
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Sidebar Layout State
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // Connectivity & Outbox Sync state
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [outboxCount, setOutboxCount] = useState(0);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncNotice, setSyncNotice] = useState<string | null>(null);

  // Vault state
  const [isVaultOpen, setIsVaultOpen] = useState(false);
  const [isVaultUnlocked, setIsVaultUnlocked] = useState(false);

  // Modals
  const [selectedStudentForDossier, setSelectedStudentForDossier] = useState<Student | null>(null);
  const [showOnboardModal, setShowOnboardModal] = useState(false);
  const [onboardForm, setOnboardForm] = useState({
    name: '',
    code: '',
    currency: 'NGN',
    currencySymbol: '₦',
    address: '',
    phone: '',
    currentSession: '2025/2026',
    currentTerm: 'First Term'
  });

  // Direct action modals
  const [showQuickEnrolModal, setShowQuickEnrolModal] = useState(false);
  const [quickEnrolForm, setQuickEnrolForm] = useState({
    admissionNo: '',
    firstName: '',
    lastName: '',
    gender: 'female' as 'male' | 'female' | 'other',
    classArm: 'JSS 1 Alpha',
    guardianName: '',
    guardianPhone: '',
    guardianEmail: ''
  });

  const [showQuickPaymentModal, setShowQuickPaymentModal] = useState(false);
  const [quickPaymentForm, setQuickPaymentForm] = useState({
    studentId: '',
    amountMajor: '',
    category: 'Tuition',
    description: '',
    paymentChannel: 'BANK_TRANSFER' as const,
    referenceNo: ''
  });

  const [showQuickNoticeModal, setShowQuickNoticeModal] = useState(false);
  const [quickNoticeForm, setQuickNoticeForm] = useState({
    title: '',
    content: '',
    priority: 'normal' as const,
    targetAudience: 'All' as const
  });

  useEffect(() => {
    loadTenantsList();
    loadAllTenantData(currentSchoolId);
    checkOutboxDepth();

    const handleOnline = () => {
      setIsOnline(true);
      triggerAutoSync();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    const interval = setInterval(checkOutboxDepth, 4000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(interval);
    };
  }, [currentSchoolId]);

  async function loadTenantsList() {
    try {
      const tenants = await api.getTenants();
      setAvailableTenants(tenants);
    } catch (e) {
      console.warn('Failed to load tenants list', e);
    }
  }

  async function loadAllTenantData(schoolId: string) {
    setLoading(true);
    try {
      api.setSchoolId(schoolId);
      const [tenantData, studentList, staffList, noticesList, summaryData] = await Promise.all([
        api.getTenant(schoolId),
        api.getStudents('all', false),
        api.getStaff(schoolId),
        api.getNotices(),
        api.getDashboardSummary()
      ]);

      setTenant(tenantData.school);
      setClasses(tenantData.classes || []);
      setSubjects(tenantData.subjects || []);
      setStudents(studentList || []);
      setStaff(staffList || []);
      setNotices(noticesList || []);
      setDashboardSummary(summaryData);
      if (tenantData.classes?.[0]?.name) {
        setQuickEnrolForm(prev => ({ ...prev, classArm: tenantData.classes[0].name }));
      }
    } catch (err) {
      console.error('Failed to load school tenant data', err);
    } finally {
      setLoading(false);
    }
  }

  async function checkOutboxDepth() {
    try {
      const count = await localDb.outbox.count();
      setOutboxCount(count);
      setIsVaultUnlocked(api.isVaultUnlocked());
    } catch {
      // safe fallback
    }
  }

  async function triggerAutoSync() {
    if (!navigator.onLine) return;
    setIsSyncing(true);
    try {
      const res = await api.syncOutbox();
      if (res.pushed > 0 || res.skipped > 0) {
        setSyncNotice(`Synced ${res.pushed} offline items. (${res.skipped} deduplicated)`);
        setTimeout(() => setSyncNotice(null), 4000);
      }
      await checkOutboxDepth();
      if (currentSchoolId) await loadAllTenantData(currentSchoolId);
    } catch (err: any) {
      console.warn('Sync attempt note:', err);
    } finally {
      setIsSyncing(false);
    }
  }

  function handleLockVault() {
    api.setCryptoKey(null);
    setIsVaultUnlocked(false);
    setSyncNotice('Offline vault locked. Keys wiped from active memory.');
    setTimeout(() => setSyncNotice(null), 3000);
  }

  async function handleToggleReportLock(locked: boolean) {
    if (!tenant) return;
    try {
      await api.toggleReportLock(locked, currentUser?.email || 'admin@school.edu');
      setTenant(prev => prev ? { ...prev, isReportsLocked: locked } : null);
      setSyncNotice(locked ? 'Term reports locked. Score mutations disabled.' : 'Term reports unlocked.');
      setTimeout(() => setSyncNotice(null), 3500);
    } catch (err: any) {
      alert(err.message || 'Error updating report lock');
    }
  }

  function handleLoginSuccess(sessionData: {
    role: UserRole;
    user: any;
    school: SchoolTenant;
    studentPortalData?: any;
    parentPortalData?: any;
  }) {
    setIsLoggedIn(true);
    setCurrentRole(sessionData.role);
    setCurrentUser(sessionData.user);
    setTenant(sessionData.school);
    setStudentPortalData(sessionData.studentPortalData || null);
    setParentPortalData(sessionData.parentPortalData || null);

    // Route default tab by role
    if (sessionData.role === 'student') {
      setActiveTab('student_portal');
    } else if (sessionData.role === 'parent') {
      setActiveTab('parent_portal');
    } else if (sessionData.role === 'teacher') {
      setActiveTab('gradebook');
    } else {
      setActiveTab('dashboard');
    }

    setAppMode('school_app');
  }

  function handleLogout() {
    setIsLoggedIn(false);
    setCurrentUser(null);
    setStudentPortalData(null);
    setParentPortalData(null);
    setActiveTab('dashboard');
    if (isSuperAdmin) {
      setAppMode('owner_dashboard');
    } else {
      setAppMode('landing');
    }
  }

  // Quick Action Submissions
  async function handleQuickEnrolSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.createStudent(quickEnrolForm, currentUser?.email || 'admin@school.edu');
      setShowQuickEnrolModal(false);
      setQuickEnrolForm({
        admissionNo: '',
        firstName: '',
        lastName: '',
        gender: 'female',
        classArm: classes[0]?.name || 'JSS 1 Alpha',
        guardianName: '',
        guardianPhone: '',
        guardianEmail: ''
      });
      setSyncNotice(`Enrolled pupil ${quickEnrolForm.firstName} ${quickEnrolForm.lastName} successfully.`);
      setTimeout(() => setSyncNotice(null), 4000);
      loadAllTenantData(currentSchoolId);
    } catch (err: any) {
      alert(err.message || 'Error enrolling student');
    }
  }

  async function handleQuickPaymentSubmit(e: React.FormEvent) {
    e.preventDefault();
    const majorVal = parseFloat(quickPaymentForm.amountMajor);
    if (isNaN(majorVal) || majorVal <= 0) {
      alert('Please enter a valid payment amount');
      return;
    }
    try {
      await api.recordPayment({
        studentId: quickPaymentForm.studentId,
        type: 'CREDIT_PAYMENT',
        amountMinor: Math.round(majorVal * 100),
        description: quickPaymentForm.description || `Tuition payment for ${quickPaymentForm.category}`,
        category: quickPaymentForm.category,
        paymentChannel: quickPaymentForm.paymentChannel,
        referenceNo: quickPaymentForm.referenceNo,
        actorEmail: currentUser?.email || 'bursar@school.edu'
      });
      setShowQuickPaymentModal(false);
      setQuickPaymentForm({
        studentId: '',
        amountMajor: '',
        category: 'Tuition',
        description: '',
        paymentChannel: 'BANK_TRANSFER',
        referenceNo: ''
      });
      setSyncNotice('Payment recorded in ledger with cryptographic receipt.');
      setTimeout(() => setSyncNotice(null), 4000);
      loadAllTenantData(currentSchoolId);
    } catch (err: any) {
      alert(err.message || 'Error recording payment');
    }
  }

  async function handleQuickNoticeSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.createNotice(quickNoticeForm, currentUser?.name || 'Administrator');
      setShowQuickNoticeModal(false);
      setQuickNoticeForm({
        title: '',
        content: '',
        priority: 'normal',
        targetAudience: 'All'
      });
      setSyncNotice('Notice published to school notice board.');
      setTimeout(() => setSyncNotice(null), 4000);
      loadAllTenantData(currentSchoolId);
    } catch (err: any) {
      alert(err.message || 'Error publishing notice');
    }
  }

  async function handleOnboardTenantSubmit(e: React.FormEvent) {
    e.preventDefault();
    try {
      const res = await fetch('/api/tenant/onboard', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(onboardForm)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to onboard school');
      setShowOnboardModal(false);
      await loadTenantsList();
      setCurrentSchoolId(data.school.id);
      setSyncNotice(`Onboarded new school tenant: ${data.school.name}`);
      setTimeout(() => setSyncNotice(null), 4000);
    } catch (err: any) {
      alert(err.message || 'Error onboarding tenant');
    }
  }

  // 1. Landing Page View (System Home)
  if (appMode === 'landing') {
    return (
      <>
        <LandingPage
          onGoToSchoolLogin={() => setAppMode('school_login')}
          onGoToOwnerLogin={() => setShowOwnerLoginModal(true)}
        />
        <OwnerLoginModal
          isOpen={showOwnerLoginModal}
          onClose={() => setShowOwnerLoginModal(false)}
          onSuccess={() => {
            setIsSuperAdmin(true);
            setAppMode('owner_dashboard');
          }}
        />
      </>
    );
  }

  // 2. Mino Official Platform Owner & Super Administrator Dashboard
  if (appMode === 'owner_dashboard') {
    return (
      <SuperAdminDashboard
        onLogout={() => {
          setIsSuperAdmin(false);
          setAppMode('landing');
        }}
        onBackToLanding={() => setAppMode('landing')}
        onLaunchSchoolPortal={(schoolId) => {
          setCurrentSchoolId(schoolId);
          loadAllTenantData(schoolId);
          setIsLoggedIn(true);
          setCurrentRole('admin');
          setCurrentUser({
            name: 'Platform Director',
            email: 'owner@mino.com',
            role: 'admin'
          });
          setAppMode('school_app');
        }}
      />
    );
  }

  // 3. School Login Door (Admin, Teacher, Parent, Student)
  if (appMode === 'school_login' || !isLoggedIn) {
    return (
      <>
        <LoginPage
          availableTenants={availableTenants}
          currentSchoolId={currentSchoolId}
          onSelectTenant={(sid) => {
            setCurrentSchoolId(sid);
            loadAllTenantData(sid);
          }}
          onOpenOnboardTenant={() => setShowOnboardModal(true)}
          onGoToOwnerLogin={() => setShowOwnerLoginModal(true)}
          onBackToLanding={() => setAppMode('landing')}
          onLoginSuccess={handleLoginSuccess}
        />

        <OwnerLoginModal
          isOpen={showOwnerLoginModal}
          onClose={() => setShowOwnerLoginModal(false)}
          onSuccess={() => {
            setIsSuperAdmin(true);
            setAppMode('owner_dashboard');
          }}
        />

        {/* Tenant Onboard Modal */}
        {showOnboardModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
            <div className="w-full max-w-md rounded-[6px] bg-white p-6 shadow-2xl border border-slate-200">
              <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                <div className="flex items-center gap-2">
                  <School className="w-4 h-4 text-[#B45309]" />
                  <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    Onboard New School Tenant
                  </h3>
                </div>
                <button onClick={() => setShowOnboardModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">×</button>
              </div>
              <form onSubmit={handleOnboardTenantSubmit} className="mt-4 space-y-3.5">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    School Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={onboardForm.name}
                    onChange={(e) => setOnboardForm({ ...onboardForm, name: e.target.value })}
                    placeholder="e.g. Greenwood Grammar School"
                    className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      School Code *
                    </label>
                    <input
                      type="text"
                      required
                      maxLength={6}
                      value={onboardForm.code}
                      onChange={(e) => setOnboardForm({ ...onboardForm, code: e.target.value })}
                      placeholder="GGS"
                      className="w-full px-3 py-2 text-xs uppercase font-mono rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                      Currency Symbol
                    </label>
                    <input
                      type="text"
                      required
                      value={onboardForm.currencySymbol}
                      onChange={(e) => setOnboardForm({ ...onboardForm, currencySymbol: e.target.value })}
                      placeholder="₦ or $ or £"
                      className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                    />
                  </div>
                </div>
                <div className="pt-2 flex gap-2">
                  <button
                    type="submit"
                    className="flex-1 py-2 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white"
                  >
                    Provision School Tenant
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowOnboardModal(false)}
                    className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-300 text-slate-700 hover:bg-slate-50"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </>
    );
  }

  // 4. LOGGED-IN: Full-Featured Figma Community School Management Admin Dashboard UI
  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900 font-sans antialiased">
      {/* 1. Left Collapsible Modern Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onSelectTab={(tabId) => {
          setActiveTab(tabId);
          setMobileMenuOpen(false);
        }}
        currentRole={currentRole}
        tenant={tenant}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        onLogout={handleLogout}
        outboxCount={outboxCount}
        isSuperAdmin={isSuperAdmin}
        onReturnToSuperAdmin={() => setAppMode('owner_dashboard')}
      />

      {/* 2. Main Workspace Layout */}
      <div className="flex-1 flex flex-col min-w-0 overflow-x-hidden">
        {/* Top Header */}
        <TopHeader
          tenant={tenant}
          activeTab={activeTab}
          currentRole={currentRole}
          currentUser={currentUser}
          isOnline={isOnline}
          outboxCount={outboxCount}
          isSyncing={isSyncing}
          isVaultUnlocked={isVaultUnlocked}
          onTriggerSync={triggerAutoSync}
          onOpenVault={() => setIsVaultOpen(true)}
          onLockVault={handleLockVault}
          onLogout={handleLogout}
          students={students}
          staff={staff}
          notices={notices}
          onSelectStudent={(st) => setSelectedStudentForDossier(st)}
          onSelectTab={(tabId) => setActiveTab(tabId)}
        />

        {/* Sync / Security Notice Banner */}
        {syncNotice && (
          <div className="bg-[#B45309] text-white text-xs py-1.5 px-4 text-center font-medium shadow-sm transition-all flex items-center justify-center gap-2 font-tabular">
            <span>{syncNotice}</span>
          </div>
        )}

        {/* 3. Main Body Viewport */}
        <main className="p-4 sm:p-6 flex-1 max-w-7xl w-full mx-auto space-y-6">
          {/* TAB 1: OVERVIEW DASHBOARD */}
          {activeTab === 'dashboard' && (
            <DashboardOverview
              summary={dashboardSummary}
              tenant={tenant}
              currencySymbol={tenant?.currencySymbol || '₦'}
              onNavigateTab={(tabId) => setActiveTab(tabId)}
              onSelectStudent={(st) => setSelectedStudentForDossier(st)}
              onOpenEnrolStudent={() => setShowQuickEnrolModal(true)}
              onOpenRecordPayment={() => setShowQuickPaymentModal(true)}
              onOpenNewNotice={() => setShowQuickNoticeModal(true)}
            />
          )}

          {/* TAB 2: STUDENTS DIRECTORY */}
          {activeTab === 'students' && (
            <StudentDirectory
              currentRole={currentRole}
              userEmail={currentUser?.email || 'admin@school.edu'}
              classes={classes}
              onSelectStudentForDetails={(st) => setSelectedStudentForDossier(st)}
            />
          )}

          {/* TAB 3: TEACHERS & STAFF */}
          {activeTab === 'staff' && (
            <StaffManagement
              currentRole={currentRole}
              userEmail={currentUser?.email || 'admin@school.edu'}
              classes={classes}
              subjects={subjects}
            />
          )}

          {/* TAB 4: PARENTS & GUARDIANS */}
          {activeTab === 'parents' && (
            <ParentsDirectory
              currencySymbol={tenant?.currencySymbol || '₦'}
            />
          )}

          {/* TAB 5: CLASSES & TIMETABLE */}
          {activeTab === 'classes' && (
            <ClassesTimetable
              classes={classes}
              subjects={subjects}
              staff={staff}
            />
          )}

          {/* TAB 6: ATTENDANCE ROLL CALL */}
          {activeTab === 'attendance' && (
            <AttendanceTracker
              classes={classes}
              userEmail={currentUser?.email || 'teacher@school.edu'}
            />
          )}

          {/* TAB 7: GRADEBOOK & EXAMS */}
          {activeTab === 'gradebook' && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-[4px] p-4 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                <div>
                  <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                    Academic Gradebook & Examination Center
                  </h2>
                  <p className="text-xs text-slate-500">
                    Input scores across Continuous Assessment (CA1, CA2), Mid-Term, and Terminal Examination.
                  </p>
                </div>
                {tenant?.isReportsLocked ? (
                  <span className="px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-red-50 text-red-800 border border-red-200 flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" /> Term Reports Locked
                  </span>
                ) : (
                  <span className="px-2.5 py-1 text-xs font-semibold rounded-[4px] bg-emerald-50 text-[#065F46] border border-emerald-200 flex items-center gap-1">
                    <Unlock className="w-3.5 h-3.5" /> Marks Entry Open
                  </span>
                )}
              </div>

              <Gradebook
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@school.edu'}
                classes={classes}
                subjects={subjects}
                isReportsLocked={tenant?.isReportsLocked || false}
                onToggleReportLock={handleToggleReportLock}
                onSyncTriggered={triggerAutoSync}
                assignedClasses={currentUser?.assignedClasses}
                assignedSubjects={currentUser?.assignedSubjects}
              />
            </div>
          )}

          {/* TAB 8: FEES & LEDGER */}
          {activeTab === 'ledger' && (
            <FeeLedger
              currentRole={currentRole}
              userEmail={currentUser?.email || 'admin@school.edu'}
              students={students}
              currencySymbol={tenant?.currencySymbol || '₦'}
            />
          )}

          {/* TAB 9: NOTICE BOARD */}
          {activeTab === 'notices' && (
            <NoticeBoard
              currentRole={currentRole}
              userEmail={currentUser?.email || 'admin@school.edu'}
            />
          )}

          {/* TAB 10: SECURITY VAULT */}
          {activeTab === 'vault' && (
            <div className="space-y-4">
              <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-[#065F46]" />
                    <div>
                      <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                        Offline Hardware-Accelerated Encryption Vault
                      </h2>
                      <p className="text-xs text-slate-500 font-medium">
                        AES-GCM-256 with 100,000 PBKDF2 rounds. Your 6-digit Master PIN is never stored or transmitted.
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setIsVaultOpen(true)}
                    className="px-3 py-1.5 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white"
                  >
                    {isVaultUnlocked ? 'Configure Vault' : 'Unlock Vault'}
                  </button>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-[4px]">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">Vault Status</span>
                    <span className={`text-base font-bold font-tabular mt-1 block ${
                      isVaultUnlocked ? 'text-[#065F46]' : 'text-[#B45309]'
                    }`}>
                      {isVaultUnlocked ? 'Active (Key in Memory)' : 'Locked'}
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-[4px]">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">Offline Outbox Items</span>
                    <span className="text-base font-bold text-slate-900 font-tabular mt-1 block">
                      {outboxCount} Queued
                    </span>
                  </div>
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-[4px]">
                    <span className="text-slate-500 block text-[10px] uppercase font-semibold">Firewall Protection</span>
                    <span className="text-base font-bold text-[#065F46] font-tabular mt-1 block">
                      Zero-Trust Rule Active
                    </span>
                  </div>
                </div>
              </div>
              <AuditTrail
                currentRole={currentRole}
                userEmail={currentUser?.email || 'admin@school.edu'}
                onDataRestored={() => loadAllTenantData(currentSchoolId)}
              />
            </div>
          )}

          {/* TAB 11: AUDIT TRAIL */}
          {activeTab === 'audit' && (
            <AuditTrail
              currentRole={currentRole}
              userEmail={currentUser?.email || 'admin@school.edu'}
              onDataRestored={() => loadAllTenantData(currentSchoolId)}
            />
          )}

          {/* ROLE PORTALS */}
          {activeTab === 'parent_portal' && (
            <ParentPortal
              initialReportData={parentPortalData}
              onLogout={handleLogout}
            />
          )}

          {activeTab === 'student_portal' && studentPortalData && (
            <StudentPortal
              studentData={studentPortalData}
              onLogout={handleLogout}
            />
          )}
        </main>
      </div>

      {/* Student Dossier Modal */}
      {selectedStudentForDossier && (
        <StudentProfileModal
          student={selectedStudentForDossier}
          onClose={() => setSelectedStudentForDossier(null)}
          currencySymbol={tenant?.currencySymbol || '₦'}
          onOpenPayment={(stdId) => {
            setQuickPaymentForm(prev => ({ ...prev, studentId: stdId }));
            setShowQuickPaymentModal(true);
          }}
        />
      )}

      {/* Offline AES-GCM Vault PIN Modal */}
      <VaultModal
        isOpen={isVaultOpen}
        onClose={() => setIsVaultOpen(false)}
        onUnlockSuccess={() => {
          setIsVaultUnlocked(true);
          setSyncNotice('Local AES-GCM-256 Vault unlocked.');
          setTimeout(() => setSyncNotice(null), 3000);
        }}
      />

      {/* Quick Enrol Pupil Modal */}
      {showQuickEnrolModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-lg rounded-[6px] bg-white p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                Quick Enrol New Pupil
              </h3>
              <button onClick={() => setShowQuickEnrolModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">×</button>
            </div>
            <form onSubmit={handleQuickEnrolSubmit} className="mt-4 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                    Admission No *
                  </label>
                  <input
                    type="text"
                    required
                    value={quickEnrolForm.admissionNo}
                    onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, admissionNo: e.target.value })}
                    placeholder="e.g. OMA/2026/015"
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                    Class Arm *
                  </label>
                  <select
                    value={quickEnrolForm.classArm}
                    onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, classArm: e.target.value })}
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  >
                    {classes.map(c => (
                      <option key={c.id} value={c.name}>{c.name}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">First Name *</label>
                  <input
                    type="text"
                    required
                    value={quickEnrolForm.firstName}
                    onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, firstName: e.target.value })}
                    placeholder="First Name"
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Last Name *</label>
                  <input
                    type="text"
                    required
                    value={quickEnrolForm.lastName}
                    onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, lastName: e.target.value })}
                    placeholder="Surname"
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Guardian Name</label>
                <input
                  type="text"
                  value={quickEnrolForm.guardianName}
                  onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, guardianName: e.target.value })}
                  placeholder="Guardian Name"
                  className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <input
                  type="tel"
                  value={quickEnrolForm.guardianPhone}
                  onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, guardianPhone: e.target.value })}
                  placeholder="Phone"
                  className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
                <input
                  type="email"
                  value={quickEnrolForm.guardianEmail}
                  onChange={(e) => setQuickEnrolForm({ ...quickEnrolForm, guardianEmail: e.target.value })}
                  placeholder="Email"
                  className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>
              <div className="pt-3 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white"
                >
                  Enrol Pupil
                </button>
                <button
                  type="button"
                  onClick={() => setShowQuickEnrolModal(false)}
                  className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Record Payment Modal */}
      {showQuickPaymentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md rounded-[6px] bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                Record Fee Payment
              </h3>
              <button onClick={() => setShowQuickPaymentModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">×</button>
            </div>
            <form onSubmit={handleQuickPaymentSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Select Pupil *</label>
                <select
                  required
                  value={quickPaymentForm.studentId}
                  onChange={(e) => setQuickPaymentForm({ ...quickPaymentForm, studentId: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                >
                  <option value="">-- Choose Pupil --</option>
                  {students.filter(s => !s.isDeleted).map(s => (
                    <option key={s.id} value={s.id}>
                      {s.firstName} {s.lastName} ({s.admissionNo}) - {s.classArm}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">
                    Amount ({tenant?.currencySymbol || '₦'}) *
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="1"
                    required
                    value={quickPaymentForm.amountMajor}
                    onChange={(e) => setQuickPaymentForm({ ...quickPaymentForm, amountMajor: e.target.value })}
                    placeholder="e.g. 50000"
                    className="w-full px-3 py-1.5 text-xs font-bold rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#065F46]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Channel</label>
                  <select
                    value={quickPaymentForm.paymentChannel}
                    onChange={(e) => setQuickPaymentForm({ ...quickPaymentForm, paymentChannel: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  >
                    <option value="BANK_TRANSFER">Bank Transfer</option>
                    <option value="CASH">Cash</option>
                    <option value="POS">POS Terminal</option>
                    <option value="ONLINE">Online Portal</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Bank Reference</label>
                <input
                  type="text"
                  value={quickPaymentForm.referenceNo}
                  onChange={(e) => setQuickPaymentForm({ ...quickPaymentForm, referenceNo: e.target.value })}
                  placeholder="e.g. TX-992831"
                  className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>
              <div className="pt-3 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold rounded-[4px] bg-[#065F46] hover:bg-[#064E3B] text-white"
                >
                  Record Payment & Issue Receipt
                </button>
                <button
                  type="button"
                  onClick={() => setShowQuickPaymentModal(false)}
                  className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quick Notice Modal */}
      {showQuickNoticeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-md rounded-[6px] bg-white p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200">
              <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wide">
                Publish School Notice
              </h3>
              <button onClick={() => setShowQuickNoticeModal(false)} className="text-slate-400 hover:text-slate-700 font-bold">×</button>
            </div>
            <form onSubmit={handleQuickNoticeSubmit} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Notice Title *</label>
                <input
                  type="text"
                  required
                  value={quickNoticeForm.title}
                  onChange={(e) => setQuickNoticeForm({ ...quickNoticeForm, title: e.target.value })}
                  placeholder="e.g. Science Fair Registration Open"
                  className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Priority</label>
                  <select
                    value={quickNoticeForm.priority}
                    onChange={(e) => setQuickNoticeForm({ ...quickNoticeForm, priority: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  >
                    <option value="normal">Normal</option>
                    <option value="urgent">Urgent Alert</option>
                    <option value="info">General Info</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Target Audience</label>
                  <select
                    value={quickNoticeForm.targetAudience}
                    onChange={(e) => setQuickNoticeForm({ ...quickNoticeForm, targetAudience: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                  >
                    <option value="All">All School</option>
                    <option value="Teachers">Teachers Only</option>
                    <option value="Parents">Parents Only</option>
                    <option value="Students">Students Only</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase mb-1">Content *</label>
                <textarea
                  rows={3}
                  required
                  value={quickNoticeForm.content}
                  onChange={(e) => setQuickNoticeForm({ ...quickNoticeForm, content: e.target.value })}
                  placeholder="Enter notice details..."
                  className="w-full p-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>
              <div className="pt-2 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white"
                >
                  Publish Notice
                </button>
                <button
                  type="button"
                  onClick={() => setShowQuickNoticeModal(false)}
                  className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
