/**
 * MINO-SMS Parents & Guardians Directory
 * View linked pupils per guardian, contact details, fee clearance status,
 * and direct WhatsApp / SMS broadcast communication templates.
 */

import React, { useState, useEffect } from 'react';
import {
  HeartHandshake,
  Search,
  MessageSquare,
  Copy,
  Check,
  Phone,
  Mail,
  ShieldCheck,
  AlertCircle,
  GraduationCap
} from 'lucide-react';
import { api } from '../services/api';
import type { ParentSummary } from '../types';

interface ParentsDirectoryProps {
  currencySymbol: string;
}

export const ParentsDirectory: React.FC<ParentsDirectoryProps> = ({ currencySymbol }) => {
  const [parents, setParents] = useState<ParentSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    loadParents();
  }, []);

  async function loadParents() {
    setLoading(true);
    try {
      const data = await api.getParents();
      setParents(data);
    } catch (e) {
      console.warn('Error loading parents directory', e);
    } finally {
      setLoading(false);
    }
  }

  function handleCopy(text: string, key: string) {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  }

  const formatMoney = (minor: number) => {
    return `${currencySymbol}${(minor / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  };

  const filteredParents = parents.filter(p => {
    const q = searchQuery.toLowerCase();
    const studentsMatch = p.students.some(s => s.name.toLowerCase().includes(q) || s.admissionNo.toLowerCase().includes(q));
    return p.guardianName.toLowerCase().includes(q) || p.guardianPhone.includes(q) || studentsMatch;
  });

  return (
    <div className="space-y-4">
      {/* Search Header */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 bg-white border border-slate-200 rounded-[4px]">
        <div>
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
            <HeartHandshake className="w-4 h-4 text-[#B45309]" />
            <span>Guardians & Parent Portal Roster</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Registered emergency contacts, portal access tokens, and fee clearance indicators.
          </p>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by guardian or student..."
            className="pl-8 pr-3 py-1.5 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A] w-64"
          />
        </div>
      </div>

      {/* Parents Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
        {loading ? (
          <div className="col-span-full py-12 text-center text-slate-400 text-xs">
            Loading parents directory...
          </div>
        ) : filteredParents.length === 0 ? (
          <div className="col-span-full py-12 text-center text-slate-400 text-xs">
            No guardian records found matching "{searchQuery}".
          </div>
        ) : (
          filteredParents.map((parent, idx) => {
            const smsText = `Dear ${parent.guardianName}, this is a notice from Oakridge Model Academy regarding your ward(s). Portal Access PIN: ${parent.accessPin}. Fee status: ${parent.isCleared ? 'Cleared' : `Outstanding balance: ${formatMoney(parent.arrearsMinor)}`}.`;
            return (
              <div
                key={idx}
                className="bg-white border border-slate-200 rounded-[4px] p-4 shadow-sm space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-100">
                    <div>
                      <h3 className="text-sm font-bold text-slate-900 font-serif">
                        {parent.guardianName}
                      </h3>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5 font-tabular">
                        <Phone className="w-3 h-3 text-slate-400" />
                        <span>{parent.guardianPhone || 'No Phone'}</span>
                      </div>
                    </div>
                    {parent.isCleared ? (
                      <span className="text-[10px] font-semibold text-[#065F46] bg-emerald-50 px-2 py-0.5 rounded-[2px] border border-emerald-200 inline-flex items-center gap-1">
                        <ShieldCheck className="w-3 h-3" /> Cleared
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold text-[#B45309] bg-amber-50 px-2 py-0.5 rounded-[2px] border border-amber-200 inline-flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" /> Arrears
                      </span>
                    )}
                  </div>

                  {/* Linked Wards */}
                  <div className="mt-2.5 space-y-1.5">
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 block">
                      Enrolled Wards ({parent.students.length})
                    </span>
                    <div className="space-y-1">
                      {parent.students.map((st) => (
                        <div
                          key={st.id}
                          className="p-1.5 rounded-[2px] bg-slate-50 text-xs flex justify-between items-center"
                        >
                          <div className="flex items-center gap-1.5">
                            <GraduationCap className="w-3.5 h-3.5 text-slate-500" />
                            <span className="font-semibold text-slate-800">{st.name}</span>
                          </div>
                          <div className="text-[11px] font-mono text-slate-500">
                            {st.classArm} · {st.admissionNo}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Financials & Portal PIN */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex justify-between items-center text-xs font-tabular">
                    <div>
                      <span className="text-[10px] text-slate-400 uppercase block font-semibold">Portal PIN</span>
                      <span className="font-mono font-bold text-slate-800">{parent.accessPin}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-slate-400 uppercase block font-semibold">Balance Due</span>
                      <span className={`font-bold ${parent.isCleared ? 'text-slate-400' : 'text-[#B45309]'}`}>
                        {formatMoney(parent.arrearsMinor)}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Instant Actions */}
                <div className="pt-2 flex gap-1.5 border-t border-slate-100">
                  {parent.guardianPhone && (
                    <a
                      href={`https://wa.me/${parent.guardianPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(smsText)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 py-1.5 text-[11px] font-semibold rounded-[3px] bg-[#065F46] hover:bg-[#064E3B] text-white flex items-center justify-center gap-1"
                    >
                      <MessageSquare className="w-3 h-3" />
                      <span>WhatsApp</span>
                    </a>
                  )}
                  <button
                    onClick={() => handleCopy(smsText, `sms_${idx}`)}
                    className="flex-1 py-1.5 text-[11px] font-semibold rounded-[3px] bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 flex items-center justify-center gap-1"
                  >
                    {copiedKey === `sms_${idx}` ? <Check className="w-3 h-3 text-[#065F46]" /> : <Copy className="w-3 h-3" />}
                    <span>{copiedKey === `sms_${idx}` ? 'Copied' : 'Copy SMS'}</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
