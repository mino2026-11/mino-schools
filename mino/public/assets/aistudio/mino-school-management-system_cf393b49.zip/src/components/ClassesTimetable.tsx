/**
 * MINO-SMS Classes & Timetable Schedule Component
 * Class arms registry, student counts, assigned class teachers,
 * and comprehensive weekly period schedule matrix (Mon-Fri).
 */

import React, { useState, useEffect } from 'react';
import {
  Layers,
  Calendar,
  Clock,
  BookOpen,
  User,
  MapPin,
  ChevronRight,
  Sparkles
} from 'lucide-react';
import { api } from '../services/api';
import type { ClassArm, Subject, StaffUser } from '../types';

interface ClassesTimetableProps {
  classes: ClassArm[];
  subjects: Subject[];
  staff: StaffUser[];
}

export const ClassesTimetable: React.FC<ClassesTimetableProps> = ({ classes, subjects, staff }) => {
  const [selectedClass, setSelectedClass] = useState<string>(classes[0]?.name || 'JSS 1 Alpha');
  const [selectedDay, setSelectedDay] = useState<'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday'>('Monday');
  const [scheduleData, setScheduleData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadSchedule();
  }, [selectedClass]);

  async function loadSchedule() {
    setLoading(true);
    try {
      const data = await api.getTimetable(selectedClass);
      setScheduleData(data.schedule || []);
    } catch (e) {
      console.warn('Error loading timetable', e);
    } finally {
      setLoading(false);
    }
  }

  const days: Array<'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday'> = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'
  ];

  const currentDaySchedule = scheduleData.find(d => d.day === selectedDay) || scheduleData[0];

  return (
    <div className="space-y-5">
      {/* Top Header */}
      <div className="bg-white border border-slate-200 rounded-[4px] p-4 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wide flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#B45309]" />
            <span>Class Arms & Weekly Master Timetable</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Class syllabus allocations, teacher room schedules, and period timetable.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Class:</span>
          <select
            value={selectedClass}
            onChange={(e) => setSelectedClass(e.target.value)}
            className="px-2.5 py-1.5 text-xs font-semibold rounded-[4px] border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-[#0F172A]"
          >
            {classes.map(c => (
              <option key={c.id} value={c.name}>{c.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Class Arm Info Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {classes.map((cls) => {
          const isCurrent = cls.name === selectedClass;
          return (
            <div
              key={cls.id}
              onClick={() => setSelectedClass(cls.name)}
              className={`p-3.5 rounded-[4px] border transition-all cursor-pointer ${
                isCurrent
                  ? 'bg-slate-900 text-white border-slate-900 shadow-md'
                  : 'bg-white border-slate-200 hover:border-slate-300 text-slate-900'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-[10px] font-mono uppercase px-1.5 py-0.2 rounded-[2px] font-semibold ${
                  isCurrent ? 'bg-slate-800 text-amber-400' : 'bg-slate-100 text-slate-600'
                }`}>
                  {cls.level}
                </span>
                <span className={`text-xs font-bold font-tabular ${isCurrent ? 'text-slate-300' : 'text-slate-500'}`}>
                  Capacity: 35
                </span>
              </div>
              <h3 className="text-base font-bold mt-2 font-serif">
                {cls.name}
              </h3>
              <div className={`text-xs mt-1.5 pt-1.5 border-t ${
                isCurrent ? 'border-slate-800 text-slate-400' : 'border-slate-100 text-slate-500'
              } flex justify-between items-center`}>
                <span>Class Teacher:</span>
                <span className={isCurrent ? 'text-white font-medium' : 'text-slate-800 font-medium'}>
                  Mr. Ogunlesi
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Weekly Timetable Schedule Matrix */}
      <div className="bg-white border border-slate-200 rounded-[4px] p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between pb-3 border-b border-slate-100 gap-3">
          <div>
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wide">
              Weekly Routine Schedule: <span className="text-[#065F46] font-bold">{selectedClass}</span>
            </h3>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Select a weekday to inspect scheduled periods, designated instructors, and room allocations.
            </p>
          </div>

          {/* Weekday Switcher Tabs */}
          <div className="flex p-0.5 bg-slate-100 rounded-[4px] border border-slate-200">
            {days.map((d) => (
              <button
                key={d}
                type="button"
                onClick={() => setSelectedDay(d)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-[3px] transition-colors ${
                  selectedDay === d
                    ? 'bg-[#0F172A] text-white shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {d.slice(0, 3)}
              </button>
            ))}
          </div>
        </div>

        {/* Periods Grid */}
        {loading ? (
          <div className="text-center py-10 text-slate-400 text-xs">Loading class timetable...</div>
        ) : !currentDaySchedule || !currentDaySchedule.periods || currentDaySchedule.periods.length === 0 ? (
          <div className="text-center py-10 text-slate-400 text-xs">No periods scheduled for this day.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {currentDaySchedule.periods.map((period: any) => (
              <div
                key={period.period}
                className="p-3.5 border border-slate-200 rounded-[4px] bg-slate-50/60 hover:bg-slate-50 transition-colors space-y-2"
              >
                <div className="flex items-center justify-between pb-1.5 border-b border-slate-200/60">
                  <span className="text-[10px] font-bold uppercase font-mono px-1.5 py-0.2 rounded-[2px] bg-slate-200 text-slate-800">
                    Period {period.period}
                  </span>
                  <span className="text-xs font-semibold text-slate-600 font-tabular flex items-center gap-1">
                    <Clock className="w-3 h-3 text-[#B45309]" />
                    {period.time}
                  </span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900 font-serif">
                    {period.subject}
                  </h4>
                  <div className="mt-1 space-y-1 text-xs text-slate-600">
                    <div className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-slate-400" />
                      <span>{period.teacher}</span>
                    </div>
                    {period.room && (
                      <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                        <MapPin className="w-3.5 h-3.5 text-[#065F46]" />
                        <span>{period.room}</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
