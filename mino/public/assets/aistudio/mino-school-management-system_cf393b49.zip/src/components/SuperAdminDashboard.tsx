/**
 * MINO Official - Platform Owner & Super Administrator Console
 * Exclusive console for the platform owner to provision, monitor,
 * configure, and manage all school tenants, subscriptions, and platform analytics.
 */

import React, { useState, useEffect } from 'react';
import {
  School,
  Users,
  GraduationCap,
  DollarSign,
  PlusCircle,
  Search,
  ShieldCheck,
  Power,
  Settings,
  Download,
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  RotateCcw,
  Sparkles,
  ArrowUpRight,
  TrendingUp,
  LogOut,
  Building2,
  Calendar,
  Lock,
  Edit3
} from 'lucide-react';
import { api } from '../services/api';
import type { PlatformAnalytics, PlatformSchoolStats, SchoolTenant } from '../types';

interface SuperAdminDashboardProps {
  onLogout: () => void;
  onLaunchSchoolPortal: (schoolId: string) => void;
  onBackToLanding: () => void;
}

export const SuperAdminDashboard: React.FC<SuperAdminDashboardProps> = ({
  onLogout,
  onLaunchSchoolPortal,
  onBackToLanding
}) => {
  const [analytics, setAnalytics] = useState<PlatformAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'suspended'>('all');
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  // Onboard modal state
  const [showProvisionModal, setShowProvisionModal] = useState(false);
  const [provisionForm, setProvisionForm] = useState({
    name: '',
    code: '',
    currency: 'NGN',
    currencySymbol: '₦',
    address: '',
    phone: '',
    currentSession: '2025/2026',
    currentTerm: 'Second Term',
    subscriptionPlan: 'Enterprise' as const,
    adminEmail: '',
    adminPasscode: 'admin123'
  });

  // Edit school modal state
  const [editingSchool, setEditingSchool] = useState<PlatformSchoolStats | null>(null);

  useEffect(() => {
    loadPlatformData();
  }, []);

  async function loadPlatformData() {
    setLoading(true);
    try {
      const data = await api.getPlatformOverview();
      setAnalytics(data);
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Failed to load platform analytics' });
    } finally {
      setLoading(false);
    }
  }

  async function handleProvisionSchool(e: React.FormEvent) {
    e.preventDefault();
    try {
      await api.createPlatformSchool(provisionForm);
      setFeedback({ type: 'success', message: `Successfully provisioned school tenant: ${provisionForm.name}` });
      setShowProvisionModal(false);
      setProvisionForm({
        name: '',
        code: '',
        currency: 'NGN',
        currencySymbol: '₦',
        address: '',
        phone: '',
        currentSession: '2025/2026',
        currentTerm: 'Second Term',
        subscriptionPlan: 'Enterprise',
        adminEmail: '',
        adminPasscode: 'admin123'
      });
      loadPlatformData();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message || 'Error provisioning school' });
    }
  }

  async function handleToggleSuspendSchool(school: PlatformSchoolStats) {
    const newStatus = school.subscriptionStatus === 'active' ? 'suspended' : 'active';
    const actionLabel = newStatus === 'suspended' ? 'suspend' : 'activate';
    if (!confirm(`Are you sure you want to ${actionLabel} access for ${school.name}?`)) return;

    try {
      await api.updatePlatformSchool(school.id, { subscriptionStatus: newStatus });
      setFeedback({ type: 'success', message: `School ${school.name} is now ${newStatus}.` });
      loadPlatformData();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message });
    }
  }

  async function handleUpdateSchoolDetails(e: React.FormEvent) {
    e.preventDefault();
    if (!editingSchool) return;

    try {
      await api.updatePlatformSchool(editingSchool.id, {
        name: editingSchool.name,
        code: editingSchool.code,
        currencySymbol: editingSchool.currencySymbol,
        subscriptionPlan: editingSchool.subscriptionPlan,
        subscriptionStatus: editingSchool.subscriptionStatus,
        currentSession: editingSchool.currentSession,
        currentTerm: editingSchool.currentTerm
      });
      setFeedback({ type: 'success', message: `Updated configuration for ${editingSchool.name}` });
      setEditingSchool(null);
      loadPlatformData();
    } catch (err: any) {
      setFeedback({ type: 'error', message: err.message });
    }
  }

  const filteredSchools = (analytics?.schools || []).filter(s => {
    const matchesSearch = s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (s.adminEmail || '').toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || s.subscriptionStatus === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="min-h-screen bg-slate-900 text-white flex flex-col antialiased">
      {/* Top Super Admin Navigation */}
      <header className="h-16 border-b border-slate-800 bg-slate-950 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-30 shadow-md">
        <div className="flex items-center gap-3">
          <img
            src="/assets/aistudio/logo_234aadf4.png"
            alt="MINO Logo"
            className="w-9 h-9 object-contain"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm tracking-tight text-white font-serif">
                MINO OFFICIAL
              </span>
              <span className="text-[10px] uppercase font-mono px-1.5 py-0.2 rounded-[2px] bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                Platform Owner Console
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono block">
              Multi-Tenant Cluster & Institutional Management
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onBackToLanding}
            className="px-3 py-1.5 text-xs font-semibold rounded-[4px] bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
          >
            Public Website
          </button>
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-[4px] bg-red-950/80 hover:bg-red-900 text-red-200 border border-red-800 transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Sign Out</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-8 space-y-6">
        {feedback && (
          <div className={`p-3 rounded-[4px] text-xs flex items-center justify-between border ${
            feedback.type === 'success'
              ? 'bg-emerald-950/80 border-emerald-800 text-emerald-300'
              : 'bg-red-950/80 border-red-800 text-red-300'
          }`}>
            <span>{feedback.message}</span>
            <button onClick={() => setFeedback(null)} className="font-bold ml-2">✕</button>
          </div>
        )}

        {/* Platform Overview Banner */}
        <div className="p-6 rounded-[6px] bg-slate-950 border border-slate-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shadow-lg">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-mono text-emerald-400 font-bold uppercase tracking-wider">
                Multi-Tenant Engine Operational
              </span>
            </div>
            <h1 className="text-2xl font-bold font-serif text-white mt-1">
              Platform Master Administration
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Provision institutions, inspect cross-school enrollments, configure subscription licensing, and access school administrative portals.
            </p>
          </div>

          <button
            onClick={() => setShowProvisionModal(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-[4px] bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold transition-colors shadow-sm"
          >
            <PlusCircle className="w-4 h-4 text-slate-950" />
            <span>Provision New School</span>
          </button>
        </div>

        {/* Global Statistics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-4 bg-slate-950 border border-slate-800 rounded-[4px]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Total School Tenants
              </span>
              <Building2 className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-bold text-white font-tabular mt-2">
              {analytics?.totalSchools || 0}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              <span className="text-emerald-400 font-bold">{analytics?.activeSchools || 0} active</span> · 0 suspended
            </div>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-[4px]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Enrolled Pupils
              </span>
              <GraduationCap className="w-4 h-4 text-emerald-400" />
            </div>
            <div className="text-2xl font-bold text-white font-tabular mt-2">
              {analytics?.totalStudents.toLocaleString() || 0}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Active student accounts across cluster
            </div>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-[4px]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Teaching Faculty
              </span>
              <Users className="w-4 h-4 text-blue-400" />
            </div>
            <div className="text-2xl font-bold text-white font-tabular mt-2">
              {analytics?.totalStaff || 0}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Teachers, Bursars & Head Teachers
            </div>
          </div>

          <div className="p-4 bg-slate-950 border border-slate-800 rounded-[4px]">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                Gross Platform Turnover
              </span>
              <DollarSign className="w-4 h-4 text-amber-400" />
            </div>
            <div className="text-2xl font-bold text-emerald-400 font-tabular mt-2">
              ₦{((analytics?.totalPlatformRevenueMinor || 0) / 100).toLocaleString('en-US', { minimumFractionDigits: 0 })}
            </div>
            <div className="text-[11px] text-slate-400 mt-1">
              Aggregated tuition collections
            </div>
          </div>
        </div>

        {/* Schools Directory & Management Section */}
        <div className="bg-slate-950 border border-slate-800 rounded-[4px] p-5 space-y-4 shadow-lg">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wide flex items-center gap-2">
                <School className="w-4 h-4 text-amber-400" />
                <span>Provisioned School Institutions ({filteredSchools.length})</span>
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Inspect institutional metrics, launch administrative portals, or modify tier licensing.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Status Filter */}
              <select
                value={statusFilter}
                onChange={(e) => setStatusFilter(e.target.value as any)}
                className="px-2.5 py-1.5 text-xs font-semibold rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500"
              >
                <option value="all">All Statuses</option>
                <option value="active">Active Only</option>
                <option value="suspended">Suspended Only</option>
              </select>

              {/* Search Box */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search by school, code, admin..."
                  className="pl-8 pr-3 py-1.5 text-xs rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500 w-52 sm:w-64"
                />
              </div>
            </div>
          </div>

          {/* School Roster Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                  <th className="py-2.5 px-3">School Name</th>
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">License Plan</th>
                  <th className="py-2.5 px-3">Enrolled Pupils</th>
                  <th className="py-2.5 px-3">Faculty</th>
                  <th className="py-2.5 px-3">Turnover</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Owner Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-tabular">
                {loading ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-slate-500 font-sans">
                      Loading provisioned institutions...
                    </td>
                  </tr>
                ) : filteredSchools.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="text-center py-8 text-slate-500 font-sans">
                      No school institutions match the current search.
                    </td>
                  </tr>
                ) : (
                  filteredSchools.map((school) => {
                    const isSuspended = school.subscriptionStatus === 'suspended';
                    return (
                      <tr key={school.id} className="hover:bg-slate-900/60 transition-colors">
                        <td className="py-3 px-3 font-sans">
                          <div className="font-bold text-white text-sm">{school.name}</div>
                          <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                            {school.adminEmail || 'admin@' + school.code.toLowerCase() + '.edu'}
                          </div>
                        </td>
                        <td className="py-3 px-3 font-mono font-bold text-amber-400">
                          {school.code}
                        </td>
                        <td className="py-3 px-3 font-sans">
                          <span className={`inline-block px-2 py-0.5 rounded-[2px] text-[10px] font-bold uppercase ${
                            school.subscriptionPlan === 'Enterprise'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                          }`}>
                            {school.subscriptionPlan || 'Enterprise'}
                          </span>
                        </td>
                        <td className="py-3 px-3 font-bold text-slate-200">
                          {school.studentCount}
                        </td>
                        <td className="py-3 px-3 text-slate-300">
                          {school.staffCount}
                        </td>
                        <td className="py-3 px-3 text-emerald-400 font-bold">
                          {school.currencySymbol}{(school.totalRevenueMinor / 100).toLocaleString('en-US', { minimumFractionDigits: 0 })}
                        </td>
                        <td className="py-3 px-3 font-sans">
                          {isSuspended ? (
                            <span className="text-[10px] font-bold uppercase text-red-400 bg-red-950/60 px-2 py-0.5 rounded border border-red-800">
                              Suspended
                            </span>
                          ) : (
                            <span className="text-[10px] font-bold uppercase text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800">
                              Active
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-3 text-right font-sans whitespace-nowrap">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => onLaunchSchoolPortal(school.id)}
                              className="px-2.5 py-1 text-xs font-semibold rounded-[3px] bg-slate-800 hover:bg-slate-700 text-white flex items-center gap-1 transition-colors"
                              title="Enter and manage this school portal as administrator"
                            >
                              <span>Enter Portal</span>
                              <ExternalLink className="w-3 h-3 text-amber-400" />
                            </button>
                            <button
                              onClick={() => setEditingSchool(school)}
                              className="p-1 text-slate-400 hover:text-white rounded-[3px]"
                              title="Edit school settings"
                            >
                              <Edit3 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleToggleSuspendSchool(school)}
                              className={`p-1 rounded-[3px] ${
                                isSuspended
                                  ? 'text-emerald-400 hover:bg-emerald-950'
                                  : 'text-red-400 hover:bg-red-950'
                              }`}
                              title={isSuspended ? 'Activate school' : 'Suspend school'}
                            >
                              <Power className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* Provision New School Modal */}
      {showProvisionModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-lg rounded-[6px] bg-slate-950 p-6 shadow-2xl border border-slate-800 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <School className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wide">
                  Provision New School Institution
                </h3>
              </div>
              <button onClick={() => setShowProvisionModal(false)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleProvisionSchool} className="mt-4 space-y-3.5 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  School Name *
                </label>
                <input
                  type="text"
                  required
                  value={provisionForm.name}
                  onChange={(e) => setProvisionForm({ ...provisionForm, name: e.target.value })}
                  placeholder="e.g. Cambridge Heritage Academy"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    School Code (3-6 Chars) *
                  </label>
                  <input
                    type="text"
                    required
                    maxLength={6}
                    value={provisionForm.code}
                    onChange={(e) => setProvisionForm({ ...provisionForm, code: e.target.value.toUpperCase() })}
                    placeholder="CHA"
                    className="w-full px-3 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Subscription Tier
                  </label>
                  <select
                    value={provisionForm.subscriptionPlan}
                    onChange={(e) => setProvisionForm({ ...provisionForm, subscriptionPlan: e.target.value as any })}
                    className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="Enterprise">Enterprise Tier (Unlimited)</option>
                    <option value="Standard">Standard Tier (Up to 1,000 Pupils)</option>
                    <option value="Basic">Basic Tier (Up to 250 Pupils)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Currency Code & Symbol
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={provisionForm.currency}
                      onChange={(e) => setProvisionForm({ ...provisionForm, currency: e.target.value.toUpperCase() })}
                      placeholder="NGN"
                      className="w-1/2 px-2 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-700 bg-slate-900 text-white"
                    />
                    <input
                      type="text"
                      value={provisionForm.currencySymbol}
                      onChange={(e) => setProvisionForm({ ...provisionForm, currencySymbol: e.target.value })}
                      placeholder="₦"
                      className="w-1/2 px-2 py-2 text-xs rounded-[4px] border border-slate-700 bg-slate-900 text-white"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                    Academic Session
                  </label>
                  <input
                    type="text"
                    value={provisionForm.currentSession}
                    onChange={(e) => setProvisionForm({ ...provisionForm, currentSession: e.target.value })}
                    placeholder="2025/2026"
                    className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div className="pt-2 border-t border-slate-800">
                <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block mb-2">
                  Initial Master Administrator Account
                </span>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[10px] text-slate-400 uppercase mb-1">Admin Email *</label>
                    <input
                      type="email"
                      required
                      value={provisionForm.adminEmail}
                      onChange={(e) => setProvisionForm({ ...provisionForm, adminEmail: e.target.value })}
                      placeholder="admin@school.edu"
                      className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-700 bg-slate-900 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] text-slate-400 uppercase mb-1">Initial Passcode *</label>
                    <input
                      type="text"
                      required
                      value={provisionForm.adminPasscode}
                      onChange={(e) => setProvisionForm({ ...provisionForm, adminPasscode: e.target.value })}
                      placeholder="admin123"
                      className="w-full px-3 py-2 text-xs font-mono rounded-[4px] border border-slate-700 bg-slate-900 text-white"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold rounded-[4px] bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold transition-colors"
                >
                  Deploy School Institution
                </button>
                <button
                  type="button"
                  onClick={() => setShowProvisionModal(false)}
                  className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Edit School Modal */}
      {editingSchool && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4">
          <div className="w-full max-w-md rounded-[6px] bg-slate-950 p-6 shadow-2xl border border-slate-800">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 className="text-sm font-bold text-white uppercase tracking-wide">
                Modify School: {editingSchool.name}
              </h3>
              <button onClick={() => setEditingSchool(null)} className="text-slate-400 hover:text-white font-bold">✕</button>
            </div>

            <form onSubmit={handleUpdateSchoolDetails} className="mt-4 space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-semibold text-slate-400 uppercase mb-1">School Name</label>
                <input
                  type="text"
                  required
                  value={editingSchool.name}
                  onChange={(e) => setEditingSchool({ ...editingSchool, name: e.target.value })}
                  className="w-full px-3 py-1.5 text-xs rounded border border-slate-700 bg-slate-900 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase mb-1">Plan Tier</label>
                  <select
                    value={editingSchool.subscriptionPlan || 'Enterprise'}
                    onChange={(e) => setEditingSchool({ ...editingSchool, subscriptionPlan: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded border border-slate-700 bg-slate-900 text-white"
                  >
                    <option value="Enterprise">Enterprise</option>
                    <option value="Standard">Standard</option>
                    <option value="Basic">Basic</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-slate-400 uppercase mb-1">Subscription Status</label>
                  <select
                    value={editingSchool.subscriptionStatus || 'active'}
                    onChange={(e) => setEditingSchool({ ...editingSchool, subscriptionStatus: e.target.value as any })}
                    className="w-full px-3 py-1.5 text-xs rounded border border-slate-700 bg-slate-900 text-white"
                  >
                    <option value="active">Active</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2 text-xs font-semibold rounded bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold"
                >
                  Save Configuration
                </button>
                <button
                  type="button"
                  onClick={() => setEditingSchool(null)}
                  className="px-4 py-2 text-xs font-medium rounded border border-slate-700 text-slate-300 hover:bg-slate-800"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
