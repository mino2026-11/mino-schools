/**
 * MINO-SMS School Management Sidebar Component
 * Faithful implementation of the Figma Community School Management Admin Dashboard.
 * Features:
 * - Brand logo & school title
 * - Collapsible toggle (desktop and mobile)
 * - Navigation links grouped by Main Operations & System Vault
 * - Active state indicator & counter badges
 * - User quick badge with role
 */

import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  Users,
  UserCheck,
  HeartHandshake,
  Layers,
  CalendarCheck,
  BookOpen,
  DollarSign,
  Bell,
  ShieldCheck,
  History,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Sparkles
} from 'lucide-react';
import type { UserRole, SchoolTenant } from '../types';

interface SidebarProps {
  activeTab: string;
  onSelectTab: (tabId: string) => void;
  currentRole: UserRole;
  tenant: SchoolTenant | null;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onLogout: () => void;
  outboxCount: number;
  isSuperAdmin?: boolean;
  onReturnToSuperAdmin?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  onSelectTab,
  currentRole,
  tenant,
  collapsed,
  onToggleCollapse,
  onLogout,
  outboxCount,
  isSuperAdmin,
  onReturnToSuperAdmin
}) => {
  // Navigation items by role
  const getAllNavItems = () => {
    if (currentRole === 'teacher') {
      return [
        { id: 'gradebook', label: 'Gradebook & Exams', icon: BookOpen },
        { id: 'attendance', label: 'Daily Roll Call', icon: CalendarCheck },
        { id: 'students', label: 'Class Pupils', icon: GraduationCap },
        { id: 'classes', label: 'Routine Timetable', icon: Layers },
        { id: 'notices', label: 'Staff Notices', icon: Bell }
      ];
    }
    if (currentRole === 'parent') {
      return [
        { id: 'parent_portal', label: 'Ward Performance', icon: GraduationCap }
      ];
    }
    if (currentRole === 'student') {
      return [
        { id: 'student_portal', label: 'Terminal Results', icon: GraduationCap }
      ];
    }
    // Administrator
    return [
      { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
      { id: 'students', label: 'Students', icon: GraduationCap },
      { id: 'staff', label: 'Teachers', icon: UserCheck },
      { id: 'parents', label: 'Parents', icon: HeartHandshake },
      { id: 'classes', label: 'Classes & Timetable', icon: Layers },
      { id: 'attendance', label: 'Attendance', icon: CalendarCheck },
      { id: 'gradebook', label: 'Exams & Grades', icon: BookOpen },
      { id: 'ledger', label: 'Fees & Finance', icon: DollarSign },
      { id: 'notices', label: 'Notice Board', icon: Bell },
      { id: 'vault', label: 'Security Vault', icon: ShieldCheck, badge: outboxCount > 0 ? String(outboxCount) : undefined },
      { id: 'audit', label: 'Audit Trail', icon: History }
    ];
  };

  const navItems = getAllNavItems();

  return (
    <aside
      className={`bg-[#0F172A] text-white flex flex-col justify-between transition-all duration-200 z-30 shrink-0 border-r border-slate-800 ${
        collapsed ? 'w-16' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div>
        <div className="h-16 flex items-center justify-between px-3.5 border-b border-slate-800">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-9 h-9 rounded-[4px] bg-slate-900 border border-slate-700/80 flex items-center justify-center p-1 shrink-0 shadow-sm overflow-hidden">
              <img
                src="/assets/aistudio/logo_234aadf4.png"
                alt="MINO Logo"
                className="w-full h-full object-contain"
              />
            </div>
            {!collapsed && (
              <div className="truncate">
                <span className="font-bold text-sm tracking-tight text-white font-serif block truncate">
                  {tenant ? tenant.name : 'MINO School'}
                </span>
                <span className="text-[10px] text-slate-400 font-mono block">
                  Admin System · {tenant?.code || 'SMS'}
                </span>
              </div>
            )}
          </div>
          <button
            onClick={onToggleCollapse}
            className="p-1 rounded-[3px] text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>

        {/* Navigation List */}
        <nav className="p-2 space-y-1 mt-2">
          {!collapsed && (
            <div className="px-3 py-1.5 text-[10px] uppercase font-bold text-slate-500 tracking-wider">
              Main Operations
            </div>
          )}
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onSelectTab(item.id)}
                title={collapsed ? item.label : undefined}
                className={`w-full flex items-center gap-3 px-3 py-2 text-xs font-semibold rounded-[4px] transition-colors relative ${
                  isActive
                    ? 'bg-[#1E293B] text-white text-shadow shadow-xs'
                    : 'text-slate-300 hover:bg-slate-800/80 hover:text-white'
                } ${collapsed ? 'justify-center px-0' : ''}`}
              >
                {isActive && (
                  <span className="absolute left-0 top-1.5 bottom-1.5 w-1 bg-[#B45309] rounded-r" />
                )}
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    isActive ? 'text-amber-400' : 'text-slate-400'
                  }`}
                />
                {!collapsed && (
                  <div className="flex-1 flex items-center justify-between truncate">
                    <span className="truncate">{item.label}</span>
                    {item.badge && (
                      <span className="px-1.5 py-0.2 rounded-[2px] bg-[#B45309] text-white text-[10px] font-mono font-bold">
                        {item.badge}
                      </span>
                    )}
                  </div>
                )}
              </button>
            );
          })}
        </nav>
      </div>

      {/* Pinned Bottom Area */}
      <div className="p-3 border-t border-slate-800 space-y-2">
        {isSuperAdmin && onReturnToSuperAdmin && (
          <button
            onClick={onReturnToSuperAdmin}
            className={`w-full flex items-center gap-2 py-1.5 px-2 rounded-[3px] bg-amber-500/10 border border-amber-500/30 text-amber-300 hover:bg-amber-500/20 text-xs font-semibold transition-colors ${
              collapsed ? 'justify-center px-0' : ''
            }`}
            title="Return to Mino Official Platform Console"
          >
            <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            {!collapsed && <span className="truncate">Platform Console</span>}
          </button>
        )}

        {!collapsed ? (
          <div className="flex items-center justify-between">
            <div className="min-w-0 pr-2">
              <span className="text-[10px] uppercase font-mono text-amber-400 font-bold block truncate">
                {currentRole}
              </span>
              <span className="text-xs font-medium text-slate-300 block truncate">
                {tenant?.currentSession}
              </span>
            </div>
            <button
              onClick={onLogout}
              className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-[3px] transition-colors"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <button
            onClick={onLogout}
            className="w-full flex justify-center p-2 text-slate-400 hover:text-red-400 hover:bg-slate-800 rounded-[3px] transition-colors"
            title="Sign Out"
          >
            <LogOut className="w-4 h-4" />
          </button>
        )}
      </div>
    </aside>
  );
};
