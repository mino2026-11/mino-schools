/**
 * MINO-SMS Public Landing Page
 * Features the official Mino logo, institutional value propositions,
 * core modules showcase, and dedicated dual entry points:
 * 1. "School Login" (for school administrators, teachers, parents, students)
 * 2. "Mino Official / Platform Owner" (for the system owner to manage all schools)
 */

import React from 'react';
import {
  GraduationCap,
  ShieldCheck,
  BookOpen,
  DollarSign,
  CalendarCheck,
  HeartHandshake,
  ArrowRight,
  CheckCircle2,
  Lock,
  WifiOff,
  Building2,
  Sparkles,
  Award,
  Layers,
  ChevronRight,
  Activity,
  School
} from 'lucide-react';

interface LandingPageProps {
  onGoToSchoolLogin: () => void;
  onGoToOwnerLogin: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onGoToSchoolLogin,
  onGoToOwnerLogin
}) => {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 flex flex-col font-sans antialiased selection:bg-amber-100 selection:text-amber-900">
      {/* 1. Top Navigation Bar (Top Bar Contract: 3-Zone) */}
      <header className="h-18 bg-white border-b border-slate-200 px-4 sm:px-8 flex items-center justify-between sticky top-0 z-40 shadow-xs">
        {/* Zone 1: Logo & Brand Wordmark */}
        <div className="flex items-center gap-3">
          <img
            src="/assets/aistudio/logo_234aadf4.png"
            alt="MINO Logo"
            className="w-10 h-10 object-contain"
          />
          <div>
            <span className="font-bold text-lg tracking-tight text-slate-900 font-serif block leading-none">
              MINO-SMS
            </span>
            <span className="text-[10px] text-slate-500 font-mono tracking-wider block mt-0.5">
              SCHOOL MANAGEMENT SYSTEM
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-xs font-semibold text-slate-600">
          <a href="#features" className="hover:text-slate-900 transition-colors">Platform Modules</a>
          <a href="#offline" className="hover:text-slate-900 transition-colors">Offline Architecture</a>
          <a href="#security" className="hover:text-slate-900 transition-colors">Zero-Trust Security</a>
          <a href="#pricing" className="hover:text-slate-900 transition-colors">Institution Tiers</a>
        </nav>

        {/* Zone 3: Dual Login CTAs */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onGoToOwnerLogin}
            className="px-3 py-2 text-xs font-semibold rounded-[4px] bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 transition-colors flex items-center gap-1.5"
            title="Platform Owner Portal for managing schools"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
            <span className="hidden sm:inline">Mino Official</span>
            <span className="sm:hidden">Owner</span>
          </button>
          <button
            onClick={onGoToSchoolLogin}
            className="px-4 py-2 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white transition-colors shadow-sm flex items-center gap-1.5"
          >
            <span>School Login</span>
            <ArrowRight className="w-3.5 h-3.5 text-amber-400" />
          </button>
        </div>
      </header>

      {/* 2. Hero Section */}
      <section className="pt-16 pb-20 px-4 sm:px-8 bg-gradient-to-b from-white to-slate-50 border-b border-slate-200">
        <div className="max-w-5xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-[4px] bg-slate-100 border border-slate-200 text-xs font-semibold text-slate-800">
            <span className="w-2 h-2 rounded-full bg-emerald-600" />
            <span>Multi-Tenant School Management & Offline Service Platform</span>
          </div>

          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold font-serif text-slate-900 tracking-tight leading-tight">
            The Complete Administration Suite for Forward-Thinking Schools.
          </h1>

          <p className="max-w-3xl mx-auto text-sm sm:text-base text-slate-600 leading-relaxed">
            Eliminate administrative bottleneck with ergonomic gradebook scoring, daily roll call registers, integer financial ledgers, and guardian self-service transcripts—powered by a hardware-accelerated AES-GCM offline vault.
          </p>

          {/* Action Hub */}
          <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
            <button
              onClick={onGoToSchoolLogin}
              className="w-full sm:w-auto px-6 py-3.5 text-xs font-bold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white flex items-center justify-center gap-2 shadow-md transition-colors"
            >
              <School className="w-4 h-4 text-amber-400" />
              <span>Enter School Management Portal</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onGoToOwnerLogin}
              className="w-full sm:w-auto px-5 py-3.5 text-xs font-semibold rounded-[4px] bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 flex items-center justify-center gap-2 transition-colors"
            >
              <ShieldCheck className="w-4 h-4 text-[#065F46]" />
              <span>Platform Owner (Manage Schools)</span>
            </button>
          </div>

          {/* Platform Metric Strip */}
          <div className="pt-10 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
            <div className="p-4 bg-white border border-slate-200 rounded-[4px] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400">Reliability</span>
              <div className="text-xl font-bold font-tabular text-slate-900 mt-1">100% Offline</div>
              <p className="text-[11px] text-slate-500 mt-0.5">Operates seamlessly without active internet</p>
            </div>
            <div className="p-4 bg-white border border-slate-200 rounded-[4px] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400">Security</span>
              <div className="text-xl font-bold font-tabular text-[#065F46] mt-1">AES-GCM-256</div>
              <p className="text-[11px] text-slate-500 mt-0.5">PBKDF2 100k rounds key derivation</p>
            </div>
            <div className="p-4 bg-white border border-slate-200 rounded-[4px] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400">Accounting</span>
              <div className="text-xl font-bold font-tabular text-slate-900 mt-1">Zero-Drift</div>
              <p className="text-[11px] text-slate-500 mt-0.5">Integer minor units & cryptographic receipts</p>
            </div>
            <div className="p-4 bg-white border border-slate-200 rounded-[4px] shadow-xs">
              <span className="text-[10px] uppercase font-bold text-slate-400">Multi-Tenancy</span>
              <div className="text-xl font-bold font-tabular text-[#B45309] mt-1">Strict Isolation</div>
              <p className="text-[11px] text-slate-500 mt-0.5">Complete partition per educational institution</p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Core Modules Showcase */}
      <section id="features" className="py-16 px-4 sm:px-8 bg-white border-b border-slate-200">
        <div className="max-w-6xl mx-auto space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs uppercase font-mono font-bold text-[#B45309] tracking-wider">
              Comprehensive Institutional Capabilities
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
              Engineered for Every School Stakeholder
            </h2>
            <p className="text-xs sm:text-sm text-slate-600">
              Purpose-built tools for school owners, academic deans, teachers, bursars, and guardians.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Module 1 */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
              <div className="w-9 h-9 rounded-[4px] bg-[#0F172A] text-amber-400 flex items-center justify-center">
                <BookOpen className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-serif">
                Ergonomic Gradebook & Assessment
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Desktop keyboard grid navigation (Tab, Arrow keys, Enter) paired with mobile thumb keypads. Computes CA1, CA2, Mid-Term, and Exam totals with immutable term locking.
              </p>
            </div>

            {/* Module 2 */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
              <div className="w-9 h-9 rounded-[4px] bg-[#065F46] text-white flex items-center justify-center">
                <DollarSign className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-serif">
                Integer Ledger & Fee Management
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Eliminates floating-point currency drift by calculating in integer minor units. Tracks tuition, arrears, and generates SHA-256 tamper-evident digital receipts.
              </p>
            </div>

            {/* Module 3 */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
              <div className="w-9 h-9 rounded-[4px] bg-[#B45309] text-white flex items-center justify-center">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-serif">
                Daily Roll Call Attendance Register
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Take class attendance with 1-click bulk marking, single-touch status toggles (Present, Late, Absent, Excused), and live weekly analytics for boys and girls.
              </p>
            </div>

            {/* Module 4 */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
              <div className="w-9 h-9 rounded-[4px] bg-slate-900 text-white flex items-center justify-center">
                <HeartHandshake className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-serif">
                Guardian & Student Portals
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Token-authenticated access for parents and pupils to inspect terminal examination report cards, historical performance trends, and fee clearance status.
              </p>
            </div>

            {/* Module 5 */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
              <div className="w-9 h-9 rounded-[4px] bg-slate-900 text-white flex items-center justify-center">
                <Layers className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-serif">
                Weekly Class Timetable & Schedule
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Structured Monday-through-Friday periods with subject syllabus allocations, assigned classroom instructors, and hall location management.
              </p>
            </div>

            {/* Module 6 */}
            <div className="p-5 bg-slate-50 border border-slate-200 rounded-[4px] space-y-3">
              <div className="w-9 h-9 rounded-[4px] bg-slate-900 text-white flex items-center justify-center">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-slate-900 font-serif">
                Platform Owner Multi-School Console
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Centralized super-admin dashboard for the platform owner to provision schools, track cross-school enrollments, manage subscriptions, and oversee platform health.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Architecture & Security */}
      <section id="offline" className="py-16 px-4 sm:px-8 bg-slate-900 text-white border-b border-slate-800">
        <div className="max-w-5xl mx-auto space-y-8">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs uppercase font-mono font-bold text-amber-400 tracking-wider">
              Offline-First & Cryptographic Invariants
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-white">
              Built for High Availability in Emerging Markets
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              When internet connectivity drops, your school operations continue uninterrupted.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="p-5 rounded-[4px] bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-400" />
                <h4 className="text-sm font-bold text-white uppercase font-sans">
                  Local Encrypted Vault (IndexedDB + WebCrypto)
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Cached pupil records, pending score events, and payments are encrypted locally in IndexedDB using AES-GCM-256. The master encryption key is derived on-device from a 6-digit PIN via PBKDF2 with 100,000 rounds. The PIN is never saved or transmitted.
              </p>
            </div>

            <div className="p-5 rounded-[4px] bg-slate-950 border border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-bold text-white uppercase font-sans">
                  Zero-Trust Authoritative Cloud Architecture
                </h4>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                Direct client reads and writes to backend storage are permanently blocked by security firewall rules. All mutations pass through an idempotent server pipeline that deduplicates replay attempts and logs an append-only audit trail.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Institutional Pricing Tiers */}
      <section id="pricing" className="py-16 px-4 sm:px-8 bg-white border-b border-slate-200">
        <div className="max-w-5xl mx-auto space-y-10">
          <div className="text-center max-w-2xl mx-auto space-y-2">
            <span className="text-xs uppercase font-mono font-bold text-[#065F46] tracking-wider">
              Transparent Licensing
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold font-serif text-slate-900">
              Tailored for Every Scale of Institution
            </h2>
            <p className="text-xs text-slate-600">
              Select an institutional tier or contact our executive team for custom deployment.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Basic */}
            <div className="p-6 bg-slate-50 border border-slate-200 rounded-[4px] space-y-4">
              <div>
                <span className="text-xs font-bold uppercase text-slate-500">Starter School</span>
                <h3 className="text-xl font-bold text-slate-900 font-serif mt-1">Basic Tier</h3>
                <div className="mt-2 text-2xl font-bold font-tabular text-slate-900">
                  ₦45,000 <span className="text-xs text-slate-500 font-normal">/ term</span>
                </div>
              </div>
              <ul className="text-xs text-slate-600 space-y-2">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> Up to 250 Enrolled Pupils</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> 15 Faculty Staff Accounts</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> Basic Gradebook & Ledger</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> PWA Offline Capability</li>
              </ul>
              <button
                onClick={onGoToSchoolLogin}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-slate-200 hover:bg-slate-300 text-slate-800 transition-colors"
              >
                Access Portal
              </button>
            </div>

            {/* Standard (Featured) */}
            <div className="p-6 bg-slate-900 text-white border-2 border-amber-500 rounded-[4px] space-y-4 shadow-xl relative">
              <span className="absolute -top-2.5 right-4 bg-amber-500 text-slate-950 font-bold text-[10px] uppercase px-2 py-0.5 rounded-[2px]">
                Most Popular
              </span>
              <div>
                <span className="text-xs font-bold uppercase text-amber-400">Growing Academy</span>
                <h3 className="text-xl font-bold text-white font-serif mt-1">Standard Tier</h3>
                <div className="mt-2 text-2xl font-bold font-tabular text-white">
                  ₦120,000 <span className="text-xs text-slate-400 font-normal">/ term</span>
                </div>
              </div>
              <ul className="text-xs text-slate-300 space-y-2">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> Up to 1,000 Enrolled Pupils</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> Unlimited Teaching Faculty</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> Guardian & Student Self-Service</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> WhatsApp & SMS Pre-filled Links</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-amber-400" /> Daily Attendance Analytics</li>
              </ul>
              <button
                onClick={onGoToSchoolLogin}
                className="w-full py-2.5 text-xs font-bold rounded-[4px] bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors"
              >
                Access Portal
              </button>
            </div>

            {/* Enterprise */}
            <div className="p-6 bg-slate-50 border border-slate-200 rounded-[4px] space-y-4">
              <div>
                <span className="text-xs font-bold uppercase text-slate-500">Institutional Network</span>
                <h3 className="text-xl font-bold text-slate-900 font-serif mt-1">Enterprise Tier</h3>
                <div className="mt-2 text-2xl font-bold font-tabular text-slate-900">
                  ₦250,000 <span className="text-xs text-slate-500 font-normal">/ term</span>
                </div>
              </div>
              <ul className="text-xs text-slate-600 space-y-2">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> Unlimited Pupils & Campuses</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> Multi-Campus Centralized Audit</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> Custom Currency & Grading Rubrics</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-[#065F46]" /> Point-in-Time Database Snapshots</li>
              </ul>
              <button
                onClick={onGoToSchoolLogin}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-slate-200 hover:bg-slate-300 text-slate-800 transition-colors"
              >
                Access Portal
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 6. Footer */}
      <footer className="py-8 px-4 sm:px-8 bg-slate-950 text-slate-400 border-t border-slate-800 text-xs">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2.5">
            <img
              src="/assets/aistudio/logo_234aadf4.png"
              alt="MINO Logo"
              className="w-6 h-6 object-contain"
            />
            <span className="font-bold text-white font-serif">MINO-SMS</span>
            <span>· Multi-Tenant School Management Platform</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <button onClick={onGoToOwnerLogin} className="hover:text-white transition-colors">
              Platform Owner Console
            </button>
            <button onClick={onGoToSchoolLogin} className="hover:text-white transition-colors">
              School Portal
            </button>
            <span>© 2026 MINO Platform Services. All rights reserved.</span>
          </div>
        </div>
      </footer>
    </div>
  );
};
