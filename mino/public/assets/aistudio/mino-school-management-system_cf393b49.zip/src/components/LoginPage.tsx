/**
 * MINO-SMS School Login Door
 * Independent login pages and authentication doors for each school role:
 * 1. Admin & Head Teacher Portal
 * 2. Class Teacher Portal
 * 3. Parent / Guardian Portal
 * 4. Student Portal
 * Plus link to Platform Owner (Mino Official) and Back to Website.
 * Clean, production-grade UI without verbose tutorial text.
 */

import React, { useState } from 'react';
import {
  Shield,
  BookOpen,
  Users,
  GraduationCap,
  ArrowRight,
  School,
  Lock,
  CheckCircle2,
  AlertCircle,
  ArrowLeft
} from 'lucide-react';
import { api } from '../services/api';
import type { UserRole, SchoolTenant } from '../types';

interface LoginPageProps {
  onLoginSuccess: (sessionData: {
    role: UserRole;
    user: any;
    school: SchoolTenant;
    studentPortalData?: any;
    parentPortalData?: any;
  }) => void;
  availableTenants: { id: string; name: string; code: string; currencySymbol: string }[];
  currentSchoolId: string;
  onSelectTenant: (schoolId: string) => void;
  onOpenOnboardTenant: () => void;
  onGoToOwnerLogin?: () => void;
  onBackToLanding?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  onLoginSuccess,
  availableTenants,
  currentSchoolId,
  onSelectTenant,
  onOpenOnboardTenant,
  onGoToOwnerLogin,
  onBackToLanding
}) => {
  const [activePortal, setActivePortal] = useState<'admin' | 'teacher' | 'parent' | 'student'>('admin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Form states
  // 1. Admin Form
  const [adminEmail, setAdminEmail] = useState('admin@oakridge.edu');
  const [adminPass, setAdminPass] = useState('admin123');

  // 2. Teacher Form
  const [teacherEmail, setTeacherEmail] = useState('teacher@oakridge.edu');
  const [teacherPass, setTeacherPass] = useState('teach123');

  // 3. Parent Form
  const [parentAdmNo, setParentAdmNo] = useState('OMA/2024/001');
  const [parentPin, setParentPin] = useState('849201');

  // 4. Student Form
  const [studentAdmNo, setStudentAdmNo] = useState('OMA/2024/001');
  const [studentPin, setStudentPin] = useState('1234');

  async function handleAdminLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.loginStaff(adminEmail, 'admin', adminPass, currentSchoolId);
      onLoginSuccess({
        role: 'admin',
        user: data.user,
        school: data.school
      });
    } catch (err: any) {
      setError(err.message || 'Admin login failed. Please verify credentials.');
    } finally {
      setLoading(false);
    }
  }

  async function handleTeacherLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.loginStaff(teacherEmail, 'teacher', teacherPass, currentSchoolId);
      onLoginSuccess({
        role: 'teacher',
        user: data.user,
        school: data.school
      });
    } catch (err: any) {
      setError(err.message || 'Teacher login failed. Please verify email and passcode.');
    } finally {
      setLoading(false);
    }
  }

  async function handleParentLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.lookupParentPortal({ admissionNo: parentAdmNo, accessPin: parentPin });
      onLoginSuccess({
        role: 'parent',
        user: { name: data.student.guardianName || 'Guardian', email: 'guardian@example.com' },
        school: data.school,
        parentPortalData: data
      });
    } catch (err: any) {
      setError(err.message || 'Parent record lookup failed. Please verify Admission No and 6-digit PIN.');
    } finally {
      setLoading(false);
    }
  }

  async function handleStudentLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const data = await api.loginStudent(studentAdmNo, studentPin, currentSchoolId);
      onLoginSuccess({
        role: 'student',
        user: data.student,
        school: data.school,
        studentPortalData: data
      });
    } catch (err: any) {
      setError(err.message || 'Student login failed. Please verify Admission No and Passcode.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center py-8 px-4 sm:px-6 lg:px-8">
      {/* Top Bar with Back to Website & Platform Owner Link */}
      <div className="sm:mx-auto sm:w-full sm:max-w-xl flex items-center justify-between mb-4">
        {onBackToLanding && (
          <button
            onClick={onBackToLanding}
            className="text-xs font-semibold text-slate-600 hover:text-slate-900 inline-flex items-center gap-1.5 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to Homepage</span>
          </button>
        )}
        {onGoToOwnerLogin && (
          <button
            onClick={onGoToOwnerLogin}
            className="text-xs font-semibold text-amber-800 hover:text-amber-900 inline-flex items-center gap-1 bg-amber-50 hover:bg-amber-100 px-2.5 py-1 rounded-[3px] border border-amber-200 transition-colors ml-auto"
          >
            <Shield className="w-3.5 h-3.5 text-amber-700" />
            <span>Login as Platform Owner (Mino Official)</span>
          </button>
        )}
      </div>

      {/* Brand Header with Real Logo Image */}
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        <img
          src="/assets/aistudio/logo_234aadf4.png"
          alt="MINO Logo"
          className="w-16 h-16 object-contain mx-auto mb-2"
        />
        <h1 className="text-2xl font-bold font-serif text-slate-900 tracking-tight">
          MINO-SMS
        </h1>
        <p className="text-xs text-slate-600 font-medium">
          Multi-Tenant Institutional Administration Portal
        </p>
      </div>

      <div className="mt-6 sm:mx-auto sm:w-full sm:max-w-xl">
        {/* Tenant Selection Card */}
        <div className="mb-4 bg-white p-3.5 rounded-[4px] border border-slate-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <School className="w-4 h-4 text-[#B45309]" />
            <div>
              <span className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider block">
                Target Institution
              </span>
              <select
                value={currentSchoolId}
                onChange={(e) => onSelectTenant(e.target.value)}
                className="text-xs font-bold text-slate-900 bg-transparent border-none p-0 focus:ring-0 cursor-pointer"
              >
                {availableTenants.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} ({t.code})
                  </option>
                ))}
              </select>
            </div>
          </div>

          <button
            onClick={onOpenOnboardTenant}
            className="text-[11px] font-semibold text-[#0F172A] hover:text-[#B45309] underline"
          >
            + Onboard New School
          </button>
        </div>

        {/* Independent Portal Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 p-1 bg-slate-200 rounded-[4px] border border-slate-300">
          <button
            onClick={() => { setActivePortal('admin'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'admin'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <Shield className={`w-4 h-4 ${activePortal === 'admin' ? 'text-[#B45309]' : 'text-slate-500'}`} />
            <span>Admin / Head</span>
          </button>

          <button
            onClick={() => { setActivePortal('teacher'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'teacher'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <BookOpen className={`w-4 h-4 ${activePortal === 'teacher' ? 'text-[#065F46]' : 'text-slate-500'}`} />
            <span>Teacher Portal</span>
          </button>

          <button
            onClick={() => { setActivePortal('parent'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'parent'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <Users className={`w-4 h-4 ${activePortal === 'parent' ? 'text-[#B45309]' : 'text-slate-500'}`} />
            <span>Guardian Portal</span>
          </button>

          <button
            onClick={() => { setActivePortal('student'); setError(null); }}
            className={`py-2 px-2 text-xs font-bold rounded-[3px] flex flex-col items-center gap-1 transition-colors ${
              activePortal === 'student'
                ? 'bg-[#0F172A] text-white shadow-sm'
                : 'text-slate-700 hover:text-slate-900 hover:bg-slate-300/50'
            }`}
          >
            <GraduationCap className={`w-4 h-4 ${activePortal === 'student' ? 'text-[#065F46]' : 'text-slate-500'}`} />
            <span>Student Portal</span>
          </button>
        </div>

        {/* Dedicated Portal Body (Clean, without verbose explanatory text) */}
        <div className="mt-3 bg-white p-6 rounded-[4px] border border-slate-200 shadow-md space-y-4">
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-[3px] text-xs text-red-800 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* 1. ADMIN LOGIN FORM */}
          {activePortal === 'admin' && (
            <form onSubmit={handleAdminLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Administrator Email
                </label>
                <input
                  type="email"
                  required
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  placeholder="admin@school.edu"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Security Passcode / Password
                </label>
                <input
                  type="password"
                  required
                  value={adminPass}
                  onChange={(e) => setAdminPass(e.target.value)}
                  placeholder="Enter passcode"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Authenticating...' : 'Sign In as Administrator'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {/* 2. TEACHER LOGIN FORM */}
          {activePortal === 'teacher' && (
            <form onSubmit={handleTeacherLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Teacher Staff Email
                </label>
                <input
                  type="email"
                  required
                  value={teacherEmail}
                  onChange={(e) => setTeacherEmail(e.target.value)}
                  placeholder="teacher@school.edu"
                  className="w-full px-3 py-2 text-xs rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Staff Login Passcode
                </label>
                <input
                  type="password"
                  required
                  value={teacherPass}
                  onChange={(e) => setTeacherPass(e.target.value)}
                  placeholder="Enter passcode"
                  className="w-full px-3 py-2 text-xs font-mono rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#0F172A] hover:bg-[#1E293B] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Entering Teacher Portal...' : 'Sign In to Gradebook'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {/* 3. PARENT LOGIN FORM */}
          {activePortal === 'parent' && (
            <form onSubmit={handleParentLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Pupil Admission Number
                </label>
                <input
                  type="text"
                  required
                  value={parentAdmNo}
                  onChange={(e) => setParentAdmNo(e.target.value)}
                  placeholder="e.g. OMA/2024/001"
                  className="w-full px-3 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  6-digit Guardian Access PIN
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  required
                  value={parentPin}
                  onChange={(e) => setParentPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••••"
                  className="w-full px-3 py-2 text-xs font-mono tracking-widest text-center rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#B45309] hover:bg-[#92400E] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Retrieving Child Record...' : 'View Student Performance & History'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}

          {/* 4. STUDENT LOGIN FORM */}
          {activePortal === 'student' && (
            <form onSubmit={handleStudentLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Student Admission Number
                </label>
                <input
                  type="text"
                  required
                  value={studentAdmNo}
                  onChange={(e) => setStudentAdmNo(e.target.value)}
                  placeholder="e.g. OMA/2024/001"
                  className="w-full px-3 py-2 text-xs font-mono uppercase rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Student Passcode / PIN
                </label>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={6}
                  required
                  value={studentPin}
                  onChange={(e) => setStudentPin(e.target.value.replace(/\D/g, ''))}
                  placeholder="••••"
                  className="w-full px-3 py-2 text-xs font-mono tracking-widest text-center rounded-[4px] border border-slate-300 focus:outline-none focus:border-[#0F172A]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 text-xs font-semibold rounded-[4px] bg-[#065F46] hover:bg-[#064E3B] text-white flex items-center justify-center gap-1.5 disabled:opacity-50 transition-colors"
              >
                <span>{loading ? 'Checking Results...' : 'View Results & Pending Payments'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
