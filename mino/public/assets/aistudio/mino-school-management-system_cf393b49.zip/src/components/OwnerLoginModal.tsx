/**
 * MINO Official Platform Owner Authentication Modal
 * Secure login gate for the platform director/owner to access the super-admin console.
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Lock,
  ArrowRight,
  AlertCircle,
  X,
  KeyRound
} from 'lucide-react';
import { api } from '../services/api';

interface OwnerLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const OwnerLoginModal: React.FC<OwnerLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess
}) => {
  const [email, setEmail] = useState('owner@mino.com');
  const [password, setPassword] = useState('mino2026');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await api.loginPlatformOwner(email, password);
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Platform Owner authentication failed.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4">
      <div className="w-full max-w-md rounded-[6px] bg-slate-950 p-6 shadow-2xl border border-slate-800 text-white">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-amber-400" />
            <h2 className="text-sm font-bold text-white uppercase tracking-wide">
              Mino Official · Platform Owner Access
            </h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white font-bold p-1">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="text-center py-4">
          <img
            src="/assets/aistudio/logo_234aadf4.png"
            alt="MINO Logo"
            className="w-14 h-14 object-contain mx-auto mb-2"
          />
          <h3 className="text-base font-bold text-white font-serif">
            Super Administrator Gate
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Authenticate to access the multi-school management console.
          </p>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-950/80 border border-red-800 rounded-[3px] text-xs text-red-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-3.5 text-xs">
          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Platform Director Email
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="owner@mino.com"
              className="w-full px-3 py-2 rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
              Master Executive Password
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Enter master password"
              className="w-full px-3 py-2 rounded-[4px] border border-slate-700 bg-slate-900 text-white focus:outline-none focus:border-amber-500 font-mono"
            />
          </div>

          <div className="pt-2 flex gap-2">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 py-2.5 text-xs font-bold rounded-[4px] bg-amber-600 hover:bg-amber-500 text-slate-950 flex items-center justify-center gap-1.5 transition-colors disabled:opacity-50"
            >
              <span>{loading ? 'Verifying...' : 'Authenticate as Platform Owner'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium rounded-[4px] border border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
